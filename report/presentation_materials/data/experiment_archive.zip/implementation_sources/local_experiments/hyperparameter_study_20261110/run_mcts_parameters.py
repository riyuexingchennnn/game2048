"""One-factor-at-a-time search-budget/depth study, original rules and RNG."""
from pathlib import Path
import ctypes,csv,gzip,hashlib,importlib.util,json,multiprocessing as mp,os,random,sys,time,traceback
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ['PYGAME_HIDE_SUPPORT_PROMPT']='1'
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
C=ROOT/'final_report_20261108/.build/report-pr-20261108/checkout'
sys.path.insert(0,str(C))
from game2048.runner import play_episode
from game2048.wrappers.MCTS.agent import MCTSAgent,MCTSConfig
from game2048.utils.common import snake_weights
spec=importlib.util.spec_from_file_location('benchmark10000',C/'report/benchmark10000/run.py')
B=importlib.util.module_from_spec(spec);spec.loader.exec_module(B)
BUILD=Path('/home/panliang/.cache/game2048-parameter-study');BUILD.mkdir(parents=True,exist_ok=True)
CONFIGS=[('sim32',dict(simulations=32)),('baseline',dict()),('sim512',dict(simulations=512)),
         ('depth6',dict(depth=6)),('depth24',dict(depth=24))]

def dump(path,value):Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

class Configured(B.FastMCTS):
    def __init__(self,overrides):
        super().__init__(BUILD)
        self.lib.mc_destroy.argtypes=[ctypes.c_void_p]
        self.lib.mc_destroy(self.handle)
        self.config=MCTSConfig(**overrides);c=self.config
        weights=(ctypes.c_double*72)(*[v for pattern in snake_weights(3) for v in pattern])
        self.handle=self.lib.mc_create(c.simulations,c.depth,c.exploration,c.rollout_random,
            c.empty_weight,c.order_weight,c.target_bonus,weights)
        self.seed(0)

def job(item):
    name,overrides=item;agent=Configured(overrides);started=time.perf_counter();rows=[]
    with gzip.open(OUT/f'mcts_{name}_raw.csv.gz','wt',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['seed','sum','max_tile','reached_256','steps']);w.writeheader()
        for seed in range(6300000,6301000):
            row=play_episode(agent,seed=seed);rows.append(row);w.writerow(row)
    result=dict(id=name,config=agent.config.__dict__,games=len(rows),
        seed_range=[6300000,6300999],mean_sum=sum(r['sum'] for r in rows)/len(rows),
        success_256=sum(r['reached_256'] for r in rows)/len(rows),
        mean_steps=sum(r['steps'] for r in rows)/len(rows),
        parallel_job_wall_seconds=time.perf_counter()-started,
        timing_note='Concurrent configurations; wall time is not a controlled speed benchmark.')
    dump(OUT/f'mcts_{name}.json',result);return result

def main():
    B.FastMCTS(BUILD)
    trace=ROOT/'final_report_20261108/output/原版界面汇报素材/乐观TD_逐步记录.json'
    records=json.loads(trace.read_text(encoding='utf-8'))['records']
    boards=[tuple(records[i]['board']) for i in [0,10,30,70,150,220,300,400]]
    for name,overrides in CONFIGS:
        fast=Configured(overrides);reference=MCTSAgent(MCTSConfig(**overrides))
        for index,board in enumerate(boards):
            seed=7400000+index;fast.seed(seed);reference.rng.seed(seed)
            assert fast.choose(board)==reference.choose(board),(name,index,'action')
            assert fast.getstate()==reference.rng.getstate(),(name,index,'rng')
    dump(OUT/'mcts_validation.json',dict(configurations=5,boards_per_configuration=8,
        matching_action_and_rng_pairs=40,native_sha256=hashlib.sha256((C/'report/benchmark10000/native_mcts.cpp').read_bytes()).hexdigest()))
    dump(OUT/'mcts_design.json',dict(configurations=CONFIGS,episodes_per_configuration=1000,
        seed_range=[6300000,6300999],policy_rng_seed='environment seed + 100000',
        workers=5,method='one factor at a time; simulations or depth; other parameters unchanged',
        no_training=True))
    print('40 configuration-specific action/RNG checks passed. Starting five parallel configurations.',flush=True)
    with mp.get_context('fork').Pool(5) as pool:
        results=[]
        for result in pool.imap_unordered(job,CONFIGS):
            results.append(result);print(json.dumps(result),flush=True)
    dump(OUT/'mcts_all_results.json',results)
    dump(OUT/'mcts_status.json',dict(status='complete',configurations=5,total_games=5000))

if __name__=='__main__':
    try:main()
    except BaseException:
        dump(OUT/'mcts_error.json',dict(traceback=traceback.format_exc()));raise
