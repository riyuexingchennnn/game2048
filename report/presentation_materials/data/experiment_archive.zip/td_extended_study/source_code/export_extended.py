"""Audit the broad TD study, plot representative lines, and update the handoff."""
from pathlib import Path
import csv, gzip, hashlib, io, json, re, shutil, sys, zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
from PIL import Image

HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[1]
OUT=HERE.parent/'TD扩展调参_20261110'; BASE=ROOT/'final_report_20261108'
TARGET=BASE/'output/大纲与素材'; STAGE=BASE/'.build/TD扩展调参待发布'
BACKUP=BASE/'.build/TD扩展更新前素材'
plt.rcParams.update({'font.family':'Microsoft YaHei','font.size':11,'axes.unicode_minus':False,
    'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':180,'axes.titlepad':13})
COLORS=['#246B9E','#D47B20','#36866B']
NAMES=['09_TD初始价值与折扣.png','10_TD学习与探索尺度.png','11_TD特征结构与训练预算.png']

def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def csvbytes(rows):
    out=io.StringIO(newline='');w=csv.DictWriter(out,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    return out.getvalue().encode('utf-8-sig')
def rawrows(p):
    with gzip.open(p,'rt',encoding='utf-8-sig') as f:return list(csv.DictReader(f))
def rawstats(rows):
    sums=np.array([int(r['sum']) for r in rows]);p=np.mean([int(r['max_tile'])>=256 for r in rows])
    assert all(int(r['truncated'])==0 for r in rows)
    return dict(mean_sum=float(sums.mean()),success_256=float(p),J=float(sums.mean()+256*p))
def style(ax,metric):
    ax.grid(axis='y',alpha=.18);ax.set_axisbelow(True)
    ax.set_ylabel('平均终局总和' if metric=='mean_sum' else '256达标率')
    if metric=='success_256':ax.yaxis.set_major_formatter(PercentFormatter(1,decimals=1))
def save(fig,name):
    fig.savefig(STAGE/'图表'/name,bbox_inches='tight');plt.close(fig)

def main():
    assert read(OUT/'status.json')['status']=='complete'
    assert not BACKUP.exists(),'Already published.'
    shutil.copytree(TARGET,STAGE,dirs_exist_ok=True)
    design=read(OUT/'design.json');summary=read(OUT/'validation_summary.json');seeds=design['seeds']
    sl={r['config']['id']:r for r in summary};configs={c['id']:c for c in design['configurations']}
    allraw=[];alllogs=[];allcheck=[];checks=[]
    for cid in configs:
        per=[]
        for seed in seeds:
            folder=OUT/f'models/{cid}/seed_{seed}';record=read(folder/'result.json')
            rows=rawrows(folder/'validation.csv.gz')
            assert [int(r['seed']) for r in rows]==list(range(7200000,7202000))
            stats=rawstats(rows)
            for key,val in stats.items():assert abs(val-record['validation'][key])<1e-10
            allraw.extend(dict(config=cid,train_seed=seed,**r) for r in rows);per.append(stats)
            alllogs.extend(dict(config=cid,train_seed=seed,**r) for r in record['train_log'])
            if cid=='reference':
                for cp in record['checkpoints']:
                    rr=rawrows(folder/f'checkpoint_{cp["episodes"]}.csv.gz');ss=rawstats(rr)
                    assert len(rr)==2000
                    if cp['episodes']==300000:assert rr==rows
                    for key,val in ss.items():assert abs(cp[key]-val)<1e-10
                    allcheck.extend(dict(episodes=cp['episodes'],train_seed=seed,**r) for r in rr)
                    checks.append(dict(episodes=cp['episodes'],train_seed=seed,**ss))
        for key in ['mean_sum','success_256','J']:
            vals=np.array([r[key] for r in per])
            assert abs(vals.mean()-sl[cid][key])<1e-10
            assert abs(vals.std(ddof=1)-sl[cid][key+'_sd'])<1e-10
    assert len(allraw)==230000 and len(allcheck)==60000
    hold=read(OUT/'holdout_summary.json');hd=read(OUT/'holdout_design.json');holdraw=[]
    for cid in hd['candidates']:
        vals=[]
        for seed in seeds:
            rr=rawrows(OUT/f'models/{cid}/seed_{seed}/holdout.csv.gz')
            assert [int(r['seed']) for r in rr]==list(range(7300000,7305000))
            ss=rawstats(rr);vals.append(ss)
            holdraw.extend(dict(config=cid,train_seed=seed,**r) for r in rr)
        sr=next(r for r in hold if r['config']['id']==cid)
        for key in ['mean_sum','success_256','J']:
            assert abs(np.mean([r[key] for r in vals])-sr[key])<1e-10
    plotrows=[]
    def curve(ax,x,ids,metric,label=None,color=None):
        y=np.array([sl[cid][metric] for cid in ids]);sd=np.array([sl[cid][metric+'_sd'] for cid in ids])
        ax.errorbar(x,y,yerr=sd,fmt='o-',color=color or COLORS[0 if metric=='mean_sum' else 1],
            lw=2,markersize=5,capsize=3,label=label)
        for xx,cid in zip(x,ids):
            plotrows.append(dict(config=cid,metric=metric,x=xx,mean=sl[cid][metric],training_seed_sd=sl[cid][metric+'_sd']))
        style(ax,metric)
    # Each panel changes a single numeric factor relative to the same baseline.
    fig,axes=plt.subplots(2,2,figsize=(12.4,8),layout='constrained')
    groups=[('optimism',[0,75,150,300,600,1200],'初始后状态价值','初始价值：从零初始化到较强乐观初始化'),
            ('gamma',[.9,.95,.99,.995,1.],'折扣因子γ','折扣γ：0.90、0.95、0.99、0.995、1.00')]
    for col,(group,xx,xlabel,title) in enumerate(groups):
        ids=[next(cid for cid,c in configs.items() if (c['group']==group or cid=='reference') and c[group]==v) for v in xx]
        for row,metric in enumerate(['mean_sum','success_256']):
            ax=axes[row,col];curve(ax,xx,ids,metric)
            ax.set(xlabel=xlabel,title=title if row==0 else '',xticks=xx)
            ax.set_xticklabels([f'{v:g}' for v in xx],rotation=30 if group=='gamma' else 0)
            if group=='gamma':
                # Closely spaced gamma values remain in their actual numerical positions.
                ax.set_xticks([.9,.925,.95,.975,1.]);ax.set_xticklabels(['0.90','0.925','0.95','0.975','1.00'],rotation=0)
            ax.axvline(300 if group=='optimism' else 1.,color='#7C8490',ls=':',lw=1,
                label='参照初值300' if group=='optimism' else '参照γ＝1')
            ax.legend(frameon=False,fontsize=9,loc='best')
            if group=='gamma' and metric=='success_256':ax.set_ylim(0,1)
    save(fig,NAMES[0])
    fig,axes=plt.subplots(2,2,figsize=(12.4,8),layout='constrained')
    for col,(group,xx,title,xlabel) in enumerate([
        ('alpha_start',[.03,.05,.1,.2,.3],'后期α固定为前期α的0.3倍','前期学习率α'),
        ('epsilon_start',[0,.005,.01,.02,.05,.1],'后期ε固定为前期ε的0.1倍','前期探索率ε')]):
        ids=[next(cid for cid,c in configs.items() if (c['group']==group or cid=='reference') and c[group]==v) for v in xx]
        plotted_x=np.array(xx)*100 if group=='epsilon_start' else xx
        for row,metric in enumerate(['mean_sum','success_256']):
            ax=axes[row,col];curve(ax,plotted_x,ids,metric)
            ax.set(xlabel=xlabel+'（%）' if group=='epsilon_start' else xlabel,title=title if row==0 else '',xticks=plotted_x)
            ax.set_xticklabels([f'{v:g}' for v in plotted_x])
    save(fig,NAMES[1])
    fig,axes=plt.subplots(2,2,figsize=(12.4,8),layout='constrained')
    widths=[4,5,6];ids=['width_4','reference','width_6']
    for row,metric in enumerate(['mean_sum','success_256']):
        ax=axes[row,0];curve(ax,widths,ids,metric,label='8方向共享',color=COLORS[0])
        sr=sl['symmetry_False'];ax.errorbar([5],[sr[metric]],yerr=[sr[metric+'_sd']],fmt='s',
            color=COLORS[1],markersize=7,capsize=4,label='只用原方向（5-tuple）')
        plotrows.append(dict(config='symmetry_False',metric=metric,x=5,mean=sr[metric],training_seed_sd=sr[metric+'_sd']))
        ax.set(xlabel='tuple长度／权重数组大小',xticks=widths,title='特征容量与对称共享' if row==0 else '')
        ax.set_xticklabels(['4格\n0.5MiB','5格\n12MiB','6格\n128MiB'])
        ax.legend(frameon=False,fontsize=10,loc='best')
        ax=axes[row,1];xx=design['checkpoints'];mean=[];sd=[]
        for ep in xx:
            vals=np.array([r[metric] for r in checks if r['episodes']==ep]);assert len(vals)==5
            mean.append(vals.mean());sd.append(vals.std(ddof=1))
            plotrows.append(dict(config='reference_checkpoint',metric=metric,x=ep,mean=mean[-1],training_seed_sd=sd[-1]))
        ax.errorbar(np.array(xx)/10000,mean,yerr=sd,fmt='o-',color=COLORS[row],lw=2,capsize=3)
        ax.set(xlabel='已训练局数（万）',xticks=np.array(xx)/10000,title='固定日程下的冻结模型测试' if row==0 else '')
        style(ax,metric)
    save(fig,NAMES[2])

    best=read(OUT/'recommended.json');bc=best['config'];bs=next(r for r in hold if r['config']['id']=='reference')
    original=next(r for r in hold if r['config']['id']=='original')
    observations=[]
    for group,label in [('optimism','初始价值'),('alpha_start','学习率整体尺度'),('epsilon_start','探索率整体尺度')]:
        candidates=[r for r in summary if r['config']['group']==group or r['config']['id']=='reference']
        top=max(candidates,key=lambda r:r['mean_sum'])
        observations.append(f"| {label} | {top['config'][group]:g} | {top['mean_sum']:.3f} | {top['success_256']:.2%} |")
    observations='\n'.join(observations)
    hold_labels={'original':'原主榜：5格，初值300，21／24万切换',
        'reference':'参照：5格，初值300，27／18万切换',
        'optimism_150.0':'5格，初值150，其他沿参照',
        'epsilon_start_0.01':'5格，ε为0.01→0.001，其他沿参照',
        'width_6':'6格，初值300，其他沿参照'}
    hold_table='\n'.join(f"| {hold_labels.get(r['config']['id'],r['config']['id'])} | {r['mean_sum']:.3f} | {r['success_256']:.2%} | {r['J']:.3f} |"
        for r in sorted(hold,key=lambda r:-r['J']))
    structure=next(r for r in hold if r['config']['width']!=5 or not r['config']['symmetry'] or r['config']['gamma']!=1)
    section=f'''### 补充调参：从参数日程扩展到初始化、折扣与特征

**超参数较多，五分钟展示只选取有代表性的调参与选取过程；全部参数、控制条件和逐局记录放在备份材料。** 建议主展示使用MCTS搜索深度、TD初始价值两例，其他TD折线用于问答。选择案例是为了讲清影响机制，不代表没有展示的参数已经不重要。

本轮以此前独立复测较好的日程作为参照：α从0.1在27万局降为0.03，ε从0.02在18万局降为0.002；其余固定初值300、对称5-tuple、γ=1、λ=0。每个条件5个训练种子（42、137、2026、31415、271828），每模型30万局，自然终局；环境及出生奖励不变。共23个条件、115份验证记录，其中原配置5个权重复用，另外110次完整训练新执行3,300万局；新增参照训练与旧权重逐项一致，保留其检查点用于训练预算比较。

每个模型冻结权重、ε=0，在共同新种子7,200,000—7,201,999上测试2,000局，共23万局；参照日程另在1／3／5／10／20／30万局保存检查点，各测试2,000局，共6万局。这些是沿同一训练过程保存的快照，没有为每个检查点重复训练。

其中30万局快照的1万条评测与参照模型验证逐项相同，是两次实际执行的重复记录，不增加独立样本数。加上12.5万局新保留集，本轮实际执行41.5万局评测，对应40.5万条不同的“模型／训练快照／环境种子”组合；图中不同快照也共享训练前缀，不能视为独立训练。

| 对照因素 | 本轮取值 | 控制条件与图 |
| --- | --- | --- |
| 初始后状态价值 | 0、75、150、300、600、1200 | 每个权重设为初值除以实际特征项数；其余固定。图09左列 |
| 折扣γ | 0.90、0.95、0.99、0.995、1.00 | 只改变自举项γV；γ＜1学习的是折扣回报，属于目标消融。图09右列 |
| 学习率整体尺度 | 前期0.03、0.05、0.1、0.2、0.3 | 后期统一为前期的0.3倍，27万局切换；比较整套学习率幅度。图10左列 |
| 探索率整体尺度 | 前期0、0.005、0.01、0.02、0.05、0.1 | 后期统一为前期的0.1倍，18万局切换。图10右列 |
| 特征结构 | 对称4／5／6-tuple；5-tuple关闭对称 | 容量、模式几何及对称共享的消融；相同训练局数，不等CPU时间。图11左列 |
| 训练预算 | 1／3／5／10／20／30万局 | 参照日程同一训练前缀的冻结快照。图11右列 |

图：[初始价值与折扣](图表/{NAMES[0]})、[学习与探索尺度](图表/{NAMES[1]})、[特征结构与训练预算](图表/{NAMES[2]})。所有点由原记录计算，无平滑；误差条是5个训练种子间样本标准差。γ采用真实数值坐标，0.99与0.995的点接近右端；没有把不同间距伪装成相同距离。

| 验证集单因素比较 | 平均总和最高的取值 | 平均终局总和 | 256达标率 |
| --- | ---: | ---: | ---: |
{observations}

这些是以参照配置为中心的单因素扫描，不能把各行的最高值直接拼成“最优组合”，因为组合后的相互影响还没有验证；最终候选保持为实际训练、评测过的配置。学习率行同时按0.3比例改变后期值，探索率行同时按0.1比例改变后期值，不能解释成只改前期值而后期不动。误差条重叠的小差异也不应被讲成稳定优势。

在23组验证结果中，固定对称5-tuple、γ=1的候选按平均总和和J＝平均总和＋256×达标率分别取前两名，加入原配置及参照日程；另外加入验证J最高的一组结构／折扣消融作诊断。候选在打开新保留集前冻结，然后每模型在7,300,000—7,304,999上测试5,000局。后者用于独立复核，不回头改训练参数。保留集中的点估计较高者也不等于唯一最优；五种子区间未作多重比较校正。

| 独立复核条件 | 平均终局总和 | 256达标率 | 综合J |
| --- | ---: | ---: | ---: |
{hold_table}

**在保留当前对称5-tuple、γ=1的条件下**，推荐配置为初始总价值{bc['optimism']:g}，α={bc['alpha_start']:g}→{bc['alpha_end']:g}（27万局），ε={bc['epsilon_start']:g}→{bc['epsilon_end']:g}（18万局），λ=0。相对本轮参照的平均总和差为{best['mean_sum_paired_difference']:+.3f}，按五个训练种子均值配对的95% t区间为[{best['mean_sum_ci95'][0]:.3f}, {best['mean_sum_ci95'][1]:.3f}]；此区间仅描述固定保留集下的训练种子波动。推荐是后续替换与万局复验的候选，当前三方法主榜、TD训练曲线和原版演示继续对应原权重，不能用这张五模型保留集表冒充单模型万局结果。

6-tuple复核取得平均{structure['mean_sum']:.3f}、达标率{structure['success_256']:.2%}，点估计高于5-tuple推荐候选，同时权重数组由12MiB增加到128MiB。本轮保留5-tuple接口作为主方法，6-tuple列为较大容量的诊断对照；不能宣称5-tuple具有最高分，或把内存增加归为免费的调参收益。

4-tuple使用2张表、131,072个float32参数（0.5MiB）；5-tuple为3张表、3,145,728参数（12MiB）；6-tuple为2张表、33,554,432参数（128MiB）。三个长度的基础模式几何也不同，结果不能只归因于“多看一个格子”。关闭对称时使用原来的3个5格模式、只查原方向，初值仍归一到相同总价值；这是共享方式消融，不是把原有8方向拆成8套不共享参数。

γ=1保留与终局总和一致的未折扣目标；γ＜1会偏重较近的出生奖励，虽然可以缓和自举误差，却改变了学习问题，不能只因训练波动变小就采用。λ本轮固定0，保留在线一步TD；没有拿其他离线多步算法的结果当成“只改一个λ”的对照。测试时ε=0固定权重，属于评测规则，不是靠测试探索率调高成绩。

'''
    rationale='''### 三个方法的参数依据与未验证范围（问答备用）

这里区分环境规则、学习／搜索超参数和实现选项。只有真正做过对照的值才写“经实验选择”；对经验值明确写经验设置，不能为保留数值补造最优性理由。

| 方法 | 参数／选项 | 当前取值及为什么采用 | 证据范围 |
| --- | --- | --- | --- |
| 共用环境 | 棋盘、目标、出生概率 | 3×3、256、2／4为0.9／0.1，位置均匀；由任务和原环境决定 | 固定规则，不作为调参收益 |
| 完整Expectimax | 深度 | None，计算到自然终局；3×3允许完整求解，免去截断叶子估值 | 当前完整求解；未以有限深度替代 |
| 完整Expectimax | target_bonus | 256；把达标偏好加入终局效用，按一个256块的数值尺度设定 | 目标偏好的设计选择，未扫描系数，不宣称最优 |
| 完整Expectimax | empty_weight／order_weight | 配置兼容值18／1；只在有限深度模式的非终局截断处生效 | 当前完整搜索不使用这两项，不能归因于它们 |
| 完整Expectimax | 对称、缓存、编码 | 8方向归一、状态记忆化、4位指数；减少重复计算 | 不改变递推目标的实现加速；没有学习率、ε或训练轮数 |
| 完整Expectimax | cache_dir | 缓存保存位置，便于反复加载 | 文件路径，不是影响策略的超参数 |
| MCTS | simulations | 512；用更多抽样降低根动作均值的波动，同时增加在线成本 | 先前模拟预算对照与当前成本实测；不是等时预算最优结论 |
| MCTS | depth | 14；在固定512次模拟的25深度扫描后，由独立确认集综合指标选择 | 有对照；与16的差距不明确，不宣称唯一最优 |
| MCTS | exploration | 70；探索项与未归一化的数百量级叶子价值相配，保留原设置 | 未独立扫描，量级理由不等于实验证明70最好 |
| MCTS | rollout_random | 0.15；启发式试走中保留少量随机分支，增加路径多样性 | 经验取值，尚未独立验证概率最优 |
| MCTS | empty_weight | 18；空格增加可操作空间，在叶子估值中给予正偏好 | 经验塑形权重，未独立扫描 |
| MCTS | order_weight | 1；保留原数字尺度的蛇形集中偏好 | 经验塑形权重，未独立扫描 |
| MCTS | target_bonus／死局扣分 | +256／−256；前者表达达标偏好，后者惩罚提前陷入死局 | 设计值；死局扣分在实现中绑定目标256，不是独立YAML参数 |
| MCTS | 根动作／回传／折扣 | 根动作取平均估值最大；回传单个叶子值，不额外折扣 | 算法定义，不把每层启发式当成逐步奖励相加 |
| TD | 初始总价值 | 原主榜300；提供乐观初始化偏好，本轮扫描0—1200并单列推荐 | 已补对照；初值不是回报的严格上界 |
| TD | α及其日程 | 原主榜0.1→0.03@21万；既控制修正速度，也影响估计波动 | 原终值、时机、形状对照，加本轮整体尺度扫描 |
| TD | ε及其日程 | 原主榜0.02→0.002@24万；控制训练时的状态访问和后续行为 | 已做终值、时机、形状和整体尺度对照；最终测试统一0 |
| TD | γ | 1；后期和前期出生数字对最终总和同等计入 | 新增0.9—1折扣消融，但不把换目标说成同一目标下的改进 |
| TD | λ | 0；一步在线TD无需维护资格迹或回合结束后回放 | 算法简化选择，未做在线TD(λ)对照，不宣称0最优 |
| TD | 特征模式、长度、对称 | 原主榜三个5格模式、8方向共享；局部表达能力与表容量折中 | 新增4／5／6格与关闭对称消融；模式几何同时变化 |
| TD | 训练局数 | 主榜30万局，固定局数便于比较 | 新增1—30万局冻结快照；不是各组CPU时间相同 |
| TD | 奖励／额外模块 | 只有出生2／4奖励；不额外加合并、达标或蛇形奖励 | 与最终总和关系清楚；本轮不改奖励塑形 |
| TD | 更新归一／数值类型 | 按特征次数平方和归一；float32权重、float64求和 | 保持α的实际更新尺度、控制内存；数值检查支持，不当作调参增益 |
| TD | 批大小 | 每1万局记录与调整参数；每一步即时更新 | 不是经验回放mini-batch，不能套用神经网络batch_size的解释 |
| 共用评测 | 随机种子、并列动作、长度保护 | 多训练种子、共同环境种子；固定动作顺序；超长局显式检查 | 复现与质量检查条件，不按最高分挑测试种子 |

'''
    guide=(STAGE/'大纲.md').read_text(encoding='utf-8')
    guide=guide.replace('TD调参与原训练曲线保留。','TD保留原主榜，补充23个条件的初始化、折扣、参数尺度、特征与训练预算对照。')
    guide=guide.replace('主目录共14个文件：8张PNG','主目录共17个文件：11张PNG')
    guide=guide.replace('五分钟展示优先使用04曲线和05中的主要结论，',
        '**超参数较多，展示只选取代表性的调参与选取过程；完整设置与实验记录见附录。** 五分钟展示优先使用04搜索深度和09初始价值中的主要结论，')
    guide=guide.replace('| 成本与核查 |', '| TD补充探索 | 09 初始价值／折扣、10 学习／探索尺度、11 特征结构／训练预算 |\n| 成本与核查 |')
    guide=guide.replace('## 训练曲线',section+'## 训练曲线',1)
    guide=guide.replace('## 报告',rationale+'## 报告',1) if '## 报告' in guide else guide.replace('## 统一成本对比',rationale+'## 统一成本对比',1)
    # Correct the earlier table's outdated "not scanned" wording while preserving main-model identity.
    guide=guide.replace('乐观探索的经验尺度；本次未独立扫描初始估值，不声称此数值最优',
        '原主榜的经验值；本轮已补0—1200对照，推荐与原模型主榜分列')
    guide=guide.replace('TD折线图的误差条及训练曲线阴影为五个训练种子间样本标准差，不是置信区间。',
        'TD折线图的误差条及训练曲线阴影为五个训练种子间样本标准差，不是置信区间；新增09—11使用本轮新验证及冻结快照。')
    guide=guide.replace('详细网格留问答','完整参数表及09—11补充探索留问答')
    guide=guide.replace('## 复核数据与实验调度',
        '新增TD扩展调参使用10个进程、每进程绑定不同物理核心的一条硬件线程，BLAS／Numba线程数均为1，避免重复开线程。训练阶段的并发耗时不写入原三方法的串行成本表；原主榜权重未变，所以原串行成本仍对应原主榜。\n\n## 复核数据与实验调度')
    (STAGE/'大纲.md').write_text(guide,encoding='utf-8')
    with zipfile.ZipFile(STAGE/'复核数据/数据与复核.zip') as z:data={n:z.read(n) for n in z.namelist()}
    for name in ['design.json','equivalence.json','validation_summary.json','holdout_design.json','holdout_summary.json','holdout_results.json','recommended.json','status.json']:
        data['TD扩展调参/设计与汇总/'+name]=(OUT/name).read_bytes()
    for name in ['td_extended.py','engine_reference.py','export_extended.py']:
        data['TD扩展调参/运行代码/'+name]=(HERE/name).read_bytes()
    for name,rows in [('验证逐局',allraw),('检查点逐局',allcheck),('保留集逐局',holdraw)]:
        data[f'TD扩展调参/逐局/{name}.csv.gz']=gzip.compress(csvbytes(rows),mtime=0)
    data['TD扩展调参/训练逐批日志.csv']=csvbytes(alllogs)
    data['TD扩展调参/折线逐点数值.csv']=csvbytes(plotrows)
    data['TD扩展调参/检查点汇总.csv']=csvbytes(checks)
    # Include only the small dependencies necessary to replay the reused controls.
    for seed in seeds:
        for cid in ['grid_a1_e1','time_a270000_e180000']:
            for suffix in ['.json','_weights.npz']:
                p=HERE/f'td_seed_{seed}/{cid}{suffix}'
                data[f'TD扩展调参/复现参照/td_seed_{seed}/{p.name}']=p.read_bytes()
    for seed in seeds:
        data[f'TD扩展调参/推荐候选权重/seed_{seed}.npz']=(OUT/f'models/{bc["id"]}/seed_{seed}/weights.npz').read_bytes()
    data['TD扩展调参/说明.txt']=('恢复项目目录后，将运行代码放回本地实验/完整调参_20261110，复现参照中的td_seed_*目录也放回该目录；然后运行td_extended.py。\n'
        '完整5种子模型由脚本重新训练；原参照依赖用于位级检查与复用，推荐候选权重不是当前主榜权重。\n'
        '09—11参数对照为新验证集；保留集只在候选冻结后打开。主榜、演示和成本继续对应原TD模型。\n').encode('utf-8')
    audits=list(csv.DictReader(io.StringIO(data['汇总/图表核对.csv'].decode('utf-8-sig'))))
    audits.append(dict(图表='09—11 TD扩展探索',核对='23条件×5种子×2000局=230000行重算；6检查点×5种子×2000局=60000行重算；独立保留集逐项核对；误差条为训练种子间样本标准差'))
    data['汇总/图表核对.csv']=csvbytes(audits)
    with zipfile.ZipFile(STAGE/'复核数据/数据与复核.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for n,content in data.items():z.writestr(n,content)
    for link in re.findall(r'\]\(([^)]+)\)',guide):
        if not link.startswith('https://'):assert (STAGE/link).is_file(),link
    files=sorted(p for p in STAGE.rglob('*') if p.is_file())
    assert len(files)==17 and sum(p.suffix=='.png' for p in files)==11
    for name in NAMES:
        with Image.open(STAGE/'图表'/name) as im:im.verify()
    with zipfile.ZipFile(STAGE/'复核数据/数据与复核.zip') as z:assert z.testzip() is None
    export=dict(files=17,png=11,validation_games=len(allraw),checkpoint_games=len(allcheck),holdout_games=len(holdraw),
        repeated_reference_final_snapshot_games=10000,distinct_evaluation_conditions=len(allraw)+len(allcheck)+len(holdraw)-10000,recommended=best)
    (OUT/'export_audit.json').write_text(json.dumps(export,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if '--publish' not in sys.argv:print(json.dumps(dict(preview=str(STAGE),**export),ensure_ascii=True));return
    archive=BASE/'output/大纲与素材.zip';tmp=archive.with_suffix('.tmp.zip')
    with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files:z.write(p,(Path('大纲与素材')/p.relative_to(STAGE)).as_posix())
    with zipfile.ZipFile(tmp) as z:
        assert len(z.namelist())==17 and z.testzip() is None
        for p in files:assert hashlib.sha256(z.read((Path('大纲与素材')/p.relative_to(STAGE)).as_posix())).digest()==hashlib.sha256(p.read_bytes()).digest()
    assert TARGET.resolve()==(ROOT/'final_report_20261108/output/大纲与素材').resolve()
    assert STAGE.resolve().is_relative_to((BASE/'.build').resolve())
    shutil.move(str(TARGET),str(BACKUP));shutil.move(str(STAGE),str(TARGET));tmp.replace(archive)
    print(json.dumps(dict(archive=str(archive),bytes=archive.stat().st_size,**export),ensure_ascii=True))

if __name__=='__main__':main()
