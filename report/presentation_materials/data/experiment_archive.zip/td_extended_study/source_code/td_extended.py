"""Preregistered broad TD study; all methods use the existing n-tuple family."""
import os
for key in ['OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMBA_NUM_THREADS']:
    os.environ[key] = '1'
from pathlib import Path
import csv, gzip, hashlib, json, multiprocessing as mp, time
import numpy as np
from numba import njit
import engine_reference as E

HERE = Path(__file__).resolve().parent
OUT = HERE.parent / 'TD扩展调参_20261110'
SEEDS = [42, 137, 2026, 31415, 271828]
VALID = np.arange(7200000, 7202000, dtype=np.int64)
HOLD = np.arange(7300000, 7305000, dtype=np.int64)
CHECKPOINTS = [10000, 30000, 50000, 100000, 200000, 300000]

def dump(path, value):
    path = Path(path); path.parent.mkdir(exist_ok=True, parents=True)
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    tmp.replace(path)

def configs():
    base = dict(id='reference', group='reference', optimism=300., alpha_start=.1,
        alpha_end=.03, epsilon_start=.02, epsilon_end=.002,
        alpha_switch=270000, epsilon_switch=180000, width=5, symmetry=True, gamma=1.)
    values = [base]
    for group, key, choices in [
        ('optimism', 'optimism', [0., 75., 150., 600., 1200.]),
        ('alpha_start', 'alpha_start', [.03, .05, .2, .3]),
        ('epsilon_start', 'epsilon_start', [0., .005, .01, .05, .1]),
        ('gamma', 'gamma', [.90, .95, .99, .995]),
        ('width', 'width', [4, 6]),
        ('symmetry', 'symmetry', [False])]:
        for v in choices:
            c = dict(base, id=f'{group}_{v}', group=group, **{key:v})
            if group == 'alpha_start': c['alpha_end'] = .3*v
            if group == 'epsilon_start': c['epsilon_end'] = .1*v
            values.append(c)
    values.append(dict(base, id='original', group='original', alpha_switch=210000, epsilon_switch=240000))
    assert len(values) == 23
    return values

CONFIGS = configs(); BYID = {c['id']:c for c in CONFIGS}

@njit(cache=True)
def train_discounted(weights, positions, tables, episodes, seed, alpha, epsilon, gamma):
    """Same online afterstate TD(0) as E, with an explicit bootstrapping discount."""
    np.random.seed(seed)
    results = np.zeros((episodes,3), dtype=np.float64)
    for ep in range(episodes):
        board = E.initial_board(); previous = np.int64(-1); pending = 0.
        length = 0
        while True:
            action, after, _ = E.greedy_td(board, weights, positions, tables, 0)
            if action < 0:
                if previous >= 0:
                    E.update(previous, pending-E.value(previous,weights,positions,tables),alpha,weights,positions,tables)
                break
            if np.random.random() < epsilon:
                legal = np.empty(4,dtype=np.int64); n=0
                for a in range(4):
                    if E.move(board,a)[0] != board: legal[n]=a; n+=1
                action = legal[np.random.randint(n)]
                after = E.move(board,action)[0]
            estimate = E.value(after,weights,positions,tables)
            if previous >= 0:
                delta = pending+gamma*estimate-E.value(previous,weights,positions,tables)
                E.update(previous,delta,alpha,weights,positions,tables)
            if length >= 4096: raise RuntimeError('Episode too long')
            previous=after; length+=1; board,pending=E.spawn(after)
        mass,maximum,_=E.stats(board)
        results[ep]=mass,1<<maximum,length
    return results

def init_worker():
    rank = mp.current_process()._identity[0]-1
    os.sched_setaffinity(0,{2*(rank%10)})

def evaluate(folder, name, weights, positions, tables, seeds):
    raw=E.evaluate(seeds,6,weights,positions,tables,0,1)
    assert not np.any(raw[:,5])
    with gzip.open(folder/f'{name}.csv.gz','wt',encoding='utf-8',newline='') as f:
        np.savetxt(f,raw,delimiter=',',fmt='%.0f',header='seed,sum,max_tile,steps,merge_score,truncated',comments='')
    return dict(games=len(raw),mean_sum=float(raw[:,1].mean()),success_256=float(np.mean(raw[:,2]>=256)),
        J=float(np.mean(raw[:,1])+256*np.mean(raw[:,2]>=256)),max_sum=int(raw[:,1].max()),steps=int(raw[:,3].sum()))

def job(task):
    cid,seed=task; c=BYID[cid]
    folder=OUT/f'models/{cid}/seed_{seed}'; folder.mkdir(parents=True,exist_ok=True)
    path=folder/'result.json'
    if path.exists(): return json.loads(path.read_text(encoding='utf-8'))
    positions,tables=E.patterns(c['width'],c['symmetry'])
    weights=np.full((int(tables.max())+1,16**c['width']),c['optimism']/len(tables),dtype=np.float32)
    started=time.perf_counter(); cpu=time.process_time(); logs=[]; checkpoint=[]
    if cid=='original':
        with np.load(HERE/f'td_seed_{seed}/grid_a1_e1_weights.npz') as a: weights=a['weights'].copy()
        logs=json.loads((HERE/f'td_seed_{seed}/grid_a1_e1.json').read_text(encoding='utf-8'))['train_log']
    else:
        for start in range(0,300000,10000):
            alpha=c['alpha_start'] if start<c['alpha_switch'] else c['alpha_end']
            epsilon=c['epsilon_start'] if start<c['epsilon_switch'] else c['epsilon_end']
            batch=train_discounted(weights,positions,tables,10000,seed+start,alpha,epsilon,c['gamma'])
            logs.append(dict(episodes=start+10000,alpha=alpha,epsilon=epsilon,
                mean_sum=float(batch[:,0].mean()),success_256=float(np.mean(batch[:,1]>=256)),steps=int(batch[:,2].sum())))
            if cid=='reference' and start+10000 in CHECKPOINTS:
                checkpoint.append(dict(episodes=start+10000,**evaluate(folder,f'checkpoint_{start+10000}',weights,positions,tables,VALID)))
        if cid=='reference':
            with np.load(HERE/f'td_seed_{seed}/time_a270000_e180000_weights.npz') as a:
                assert np.array_equal(weights,a['weights']),('reference weights',seed)
    train_wall=time.perf_counter()-started; train_cpu=time.process_time()-cpu
    validation=evaluate(folder,'validation',weights,positions,tables,VALID)
    config=dict(c,episodes=300000,objective=0,training_seed=seed)
    np.savez_compressed(folder/'weights.npz',weights=weights,positions=positions,tables=tables,
                        config=json.dumps(config))
    result=dict(config=c,seed=seed,validation=validation,train_log=logs,checkpoints=checkpoint,
        wall_seconds=train_wall,cpu_seconds=train_cpu,weights_bytes=weights.nbytes,
        reused_original=cid=='original',affinity=list(os.sched_getaffinity(0)))
    dump(path,result); return result

def summarize(results):
    out=[]
    for c in CONFIGS:
        rows=[r for r in results if r['config']['id']==c['id']]
        assert len(rows)==5
        d=dict(config=c)
        for m in ['mean_sum','success_256','J']:
            vals=np.array([r['validation'][m] for r in rows]);d[m]=float(vals.mean());d[m+'_sd']=float(vals.std(ddof=1))
        out.append(d)
    return out

def holdout_job(task):
    cid,seed=task;folder=OUT/f'models/{cid}/seed_{seed}';path=folder/'holdout.json'
    if path.exists():return json.loads(path.read_text(encoding='utf-8'))
    with np.load(folder/'weights.npz') as a:w,p,t=[a[k].copy() for k in ['weights','positions','tables']]
    result=dict(config=cid,seed=seed,**evaluate(folder,'holdout',w,p,t,HOLD));dump(path,result);return result

def main():
    OUT.mkdir(exist_ok=True,parents=True)
    started=time.perf_counter()
    dump(OUT/'design.json',dict(configurations=CONFIGS,seeds=SEEDS,episodes_per_model=300000,
        validation_seeds=[7200000,7201999],holdout_seeds=[7300000,7304999],workers=10,
        checkpoints=CHECKPOINTS,baseline='prior independently checked timing candidate: alpha switch270k, epsilon switch180k',
        selection='validation top2 mean, top2 J among fixed 5-tuple symmetric gamma1 variants, plus original/reference; add one top-J nonproduction structural/discount ablation; freeze candidates before fresh holdout',
        production_eligibility='width5, symmetry=True, gamma1; other variants assess capacity/goal changes and are not silently substituted',
        rollout_policy='epsilon-greedy online afterstate TD(0)',reward='spawned 2/4 only, no extra target bonus',
        initial_alpha_comparison='late alpha = 0.3 * early alpha',
        initial_epsilon_comparison='late epsilon = 0.1 * early epsilon',
        no_gamma_reward_equivalence='gamma<1 changes the learned discounted objective; evaluate original terminal metrics',
        main_ranking='old main model stays fixed; this is an independently evaluated parameter study',
        executed_training_games=22*5*300000,reused_original_models=5,
        resource_note='10 processes, each pinned to one thread of a distinct physical core; parallel wall times are not production cost measurements'))
    # Exact gamma=1 equivalence: multiple seeds, no change to reward/RNG/update order.
    p,t=E.patterns(5,True)
    for seed in [42,137]:
        a=np.full((3,16**5),12.5,dtype=np.float32); b=a.copy()
        x=E.train_batch(a,p,t,50,seed,.1,.02,0,0.)
        y=train_discounted(b,p,t,50,seed,.1,.02,1.)
        assert np.array_equal(a,b) and np.array_equal(x,y),'gamma1 equivalence'
    E.evaluate(VALID[:1],6,a,p,t,0,1)
    dump(OUT/'equivalence.json',dict(gamma1_training_checks=2,episodes_per_check=50,
        weights_and_episode_records_identical=True,full300k_reference_reproduction='checked separately for each of the five seeds',
        engine_sha256=hashlib.sha256((HERE/'engine_reference.py').read_bytes()).hexdigest()))
    tasks=[(c['id'],s) for c in CONFIGS for s in SEEDS]
    tasks.sort(key=lambda x:BYID[x[0]]['width'],reverse=True)
    results=[]
    with mp.get_context('fork').Pool(10,initializer=init_worker) as pool:
        for r in pool.imap_unordered(job,tasks):
            results.append(r)
            dump(OUT/'status.json',dict(status='running',phase='training',models=len(results),total=115,wall_seconds=time.perf_counter()-started))
            print(json.dumps(dict(done=len(results),total=115,config=r['config']['id'],seed=r['seed'],mean=r['validation']['mean_sum']),ensure_ascii=True),flush=True)
    summaries=summarize(results);dump(OUT/'validation_summary.json',summaries)
    eligible=[r for r in summaries if r['config']['width']==5 and r['config']['symmetry'] and r['config']['gamma']==1]
    ids={'original','reference'}
    for metric in ['mean_sum','J']:
        ids.update(r['config']['id'] for r in sorted(eligible,key=lambda r:-r[metric])[:2])
    nonprod=[r for r in summaries if r not in eligible]
    ids.add(max(nonprod,key=lambda r:r['J'])['config']['id'])
    dump(OUT/'holdout_design.json',dict(candidates=sorted(ids),locked_before_testing=True,production_eligibility='width5 symmetryTrue gamma1'))
    hold=[]
    with mp.get_context('fork').Pool(10,initializer=init_worker) as pool:
        for r in pool.imap_unordered(holdout_job,[(cid,s) for cid in sorted(ids) for s in SEEDS]):
            hold.append(r)
            dump(OUT/'status.json',dict(status='running',phase='holdout',models=len(hold),total=len(ids)*5))
    dump(OUT/'holdout_results.json',hold)
    summary=[]
    base={r['seed']:r for r in hold if r['config']=='reference'}
    for cid in sorted(ids):
        rows=sorted([r for r in hold if r['config']==cid],key=lambda r:r['seed'])
        row=dict(config=BYID[cid])
        for m in ['mean_sum','success_256','J']:
            vals=np.array([r[m] for r in rows]);row[m]=float(vals.mean());row[m+'_sd']=float(vals.std(ddof=1))
            dif=np.array([r[m]-base[r['seed']][m] for r in rows]);margin=2.776445105*dif.std(ddof=1)/np.sqrt(5)
            row[m+'_paired_difference']=float(dif.mean());row[m+'_ci95']=[float(dif.mean()-margin),float(dif.mean()+margin)]
        summary.append(row)
    dump(OUT/'holdout_summary.json',summary)
    prod=[r for r in summary if r['config']['width']==5 and r['config']['symmetry'] and r['config']['gamma']==1]
    best=max(prod,key=lambda r:r['J']);dump(OUT/'recommended.json',dict(**best,source='fresh holdout point estimate; exploratory, not a claim of unique optimum',main_model_unchanged=True))
    dump(OUT/'status.json',dict(status='complete',configs=23,models=115,new_training_games=33000000,
        validation_games=230000,holdout_games=len(ids)*5*5000,wall_seconds=time.perf_counter()-started))
    print('TD_EXTENDED_COMPLETE',flush=True)

if __name__=='__main__':main()
