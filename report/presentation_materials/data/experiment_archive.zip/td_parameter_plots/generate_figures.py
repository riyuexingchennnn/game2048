"""Replace TD heatmaps with controlled comparisons and actual training curves."""
from pathlib import Path
import csv
import hashlib
import io
import json
import re
import shutil
import zipfile

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import PercentFormatter
from PIL import Image

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BASE = ROOT / 'final_report_20261108'
TARGET = BASE / 'output/大纲与素材'
STAGE = BASE / '.build/TD折线图待发布'
BACKUP = BASE / '.build/TD折线图更新前素材'
plt.rcParams.update({'font.family': 'Microsoft YaHei', 'font.size': 11,
    'axes.unicode_minus': False, 'axes.spines.top': False,
    'axes.spines.right': False, 'savefig.dpi': 180, 'axes.titlepad': 13})
COLORS = ['#246B9E', '#D47B20', '#36866B']
OLD = ['05_TD参数数值热力图.png', '06_TD切换时机热力图.png', '07_TD参数日程与结果.png']
NEW = ['05_TD学习率与探索率折线图.png', '06_TD切换时机折线图.png', '07_TD参数日程与训练曲线.png']

def csvbytes(rows):
    out = io.StringIO(newline='')
    writer = csv.DictWriter(out, fieldnames=list(rows[0]))
    writer.writeheader(); writer.writerows(rows)
    return out.getvalue().encode('utf-8-sig')

def save(fig, name):
    fig.savefig(STAGE / '图表' / name, bbox_inches='tight')
    plt.close(fig)

def style(ax):
    ax.grid(axis='y', alpha=.18)
    ax.set_axisbelow(True)

def main():
    assert not BACKUP.exists(), 'Already published; preserve the prior version.'
    shutil.copytree(TARGET, STAGE, dirs_exist_ok=True)
    records = json.loads((HERE / 'td_grid_results.json').read_text(encoding='utf-8'))
    design = json.loads((HERE / 'td_design.json').read_text(encoding='utf-8'))
    seeds = design['training_seeds']
    lookup = {(r['config']['id'], r['train_seed']): r for r in records}
    assert len(lookup) == 175 and len(seeds) == 5
    configs = {r['id']: r for r in design['configurations']}
    summary = {}
    for cid in configs:
        row = {}
        for metric in ['mean_sum', 'success_256']:
            values = np.array([lookup[cid, seed][metric] for seed in seeds])
            row[metric] = float(values.mean())
            row[metric + '_sd'] = float(values.std(ddof=1))
        summary[cid] = row
    archive = STAGE / '复核数据/数据与复核.zip'
    with zipfile.ZipFile(archive) as z:
        data = {n: z.read(n) for n in z.namelist()}
    oldsummary = list(csv.DictReader(io.StringIO(data['汇总/TD配置汇总.csv'].decode('utf-8-sig'))))
    for row in oldsummary:
        for metric in ['mean_sum', 'success_256']:
            assert abs(float(row[metric]) - summary[row['id']][metric]) < 1e-10
    plotrows = []
    def audit(chart, series, x, cid, metric):
        r = summary[cid]
        plotrows.append(dict(chart=chart, series=series, x=x, config=cid,
            metric=metric, mean=r[metric], training_seed_sd=r[metric + '_sd'],
            models=5, test_games_per_model=2000))

    # One varying factor in each column keeps the comparisons easy to explain.
    fig, axes = plt.subplots(2, 2, figsize=(12.4, 8.0), layout='constrained')
    sweeps = [([.01, .03, .05, .10, .20], [f'grid_a{i}_e1' for i in range(5)],
               '后期学习率α', '固定后期ε＝0.002，只改变α'),
              ([0, .002, .005, .010, .020], [f'grid_a1_e{i}' for i in range(5)],
               '后期探索率ε', '固定后期α＝0.03，只改变ε')]
    for col, (x, ids, xlabel, title) in enumerate(sweeps):
        for row, metric in enumerate(['mean_sum', 'success_256']):
            ax = axes[row, col]
            y = np.array([summary[cid][metric] for cid in ids])
            sd = np.array([summary[cid][metric + '_sd'] for cid in ids])
            ax.errorbar(x, y, yerr=sd, fmt='o-', color=COLORS[row], lw=2,
                        markersize=6, capsize=4, elinewidth=1.2)
            ax.set(xlabel=xlabel, ylabel='平均终局总和' if row == 0 else '256达标率',
                   xticks=x, title=title if row == 0 else '')
            ax.set_xticklabels([f'{v:g}' for v in x])
            ax.set_ylim((580, 670) if row == 0 else (.88, .95))
            if row:
                ax.yaxis.set_major_formatter(PercentFormatter(1, decimals=0))
            for j, cid in enumerate(ids):
                label = f'{y[j]:.1f}' if row == 0 else f'{y[j]:.2%}'
                ax.annotate(label, (x[j], y[j] + sd[j]), xytext=(0, 7),
                            textcoords='offset points', ha='center', fontsize=9)
                audit('05', title, x[j], cid, metric)
            style(ax)
    save(fig, NEW[0])

    # All nine timing configurations, grouped into three easily tracked lines.
    fig, axes = plt.subplots(1, 2, figsize=(12.4, 4.9), layout='constrained')
    for ax, metric in zip(axes, ['mean_sum', 'success_256']):
        for es, color in zip([180000, 240000, 270000], COLORS):
            aa = [150000, 210000, 270000]
            ids = ['grid_a1_e1' if (a, es) == (210000, 240000)
                   else f'time_a{a}_e{es}' for a in aa]
            x = np.array(aa) / 10000
            y = [summary[cid][metric] for cid in ids]
            sd = [summary[cid][metric + '_sd'] for cid in ids]
            ax.errorbar(x, y, yerr=sd, fmt='o-', lw=2, capsize=3,
                        color=color, label=f'{es // 10000}万局降低ε')
            for a, cid in zip(aa, ids):
                audit('06', f'epsilon_switch={es}', a, cid, metric)
        ax.set(xlabel='降低学习率α的时间（万局）', xticks=[15, 21, 27],
               ylabel='平均终局总和' if metric == 'mean_sum' else '256达标率',
               title='学习率切换时间对平均总和的影响' if metric == 'mean_sum'
                     else '学习率切换时间对达标率的影响')
        ax.set_ylim((615, 680) if metric == 'mean_sum' else (.90, .955))
        if metric == 'success_256':
            ax.yaxis.set_major_formatter(PercentFormatter(1, decimals=0))
        ax.legend(frameon=False, loc='upper left', fontsize=10)
        style(ax)
    save(fig, NEW[1])

    # Training progresses on a real numerical axis; no line joining unordered methods.
    fig, axes = plt.subplots(2, 2, figsize=(12.4, 8.0), layout='constrained')
    training_rows = []
    for cid, label, color in zip(['grid_a1_e1', 'linear', 'cosine'],
                                 ['分段降低', '线性渐变', '余弦渐变'], COLORS):
        schedule = np.array(configs[cid]['schedule'])
        starts = np.arange(30)
        for col in range(2):
            axes[0, col].step(np.r_[starts, 30], np.r_[schedule[:, col], schedule[-1, col]],
                              where='post', label=label, color=color, lw=2)
        for col, metric in enumerate(['mean_sum', 'success_256']):
            logs = [lookup[cid, seed]['train_log'] for seed in seeds]
            assert all(len(log) == 30 for log in logs)
            assert all([p['episodes'] for p in log] == list(range(10000, 300001, 10000)) for log in logs)
            for log in logs:
                assert np.allclose([[p['alpha'], p['epsilon']] for p in log], schedule)
            values = np.array([[p[metric] for p in log] for log in logs])
            mean = values.mean(axis=0); sd = values.std(axis=0, ddof=1)
            x = np.arange(1, 31)
            ax = axes[1, col]
            ax.plot(x, mean, color=color, label=label, lw=2)
            ax.fill_between(x, mean - sd, mean + sd, color=color, alpha=.09)
            for i in range(30):
                training_rows.append(dict(config=cid, metric=metric, episodes=(i+1)*10000,
                    mean=mean[i], training_seed_sd=sd[i], models=5, training_games_per_batch=10000))
    for col in range(2):
        axes[0, col].set(xlabel='已完成训练局数（万）', ylabel='学习率α' if col == 0 else '探索率ε',
                        title='实际使用的学习率' if col == 0 else '实际使用的探索率', xlim=(0, 30))
        axes[1, col].set(xlabel='已完成训练局数（万）',
                        ylabel='平均终局总和' if col == 0 else '256达标率',
                        title='训练得分随局数变化' if col == 0 else '训练达标率随局数变化',
                        xlim=(0, 30), ylim=(0, 750) if col == 0 else (0, 1))
    axes[1, 1].yaxis.set_major_formatter(PercentFormatter(1, decimals=0))
    for ax in axes.flat:
        ax.legend(frameon=False, fontsize=10, loc='lower left' if ax in axes[0] else 'lower right')
        style(ax)
    save(fig, NEW[2])

    guide = (STAGE / '大纲.md').read_text(encoding='utf-8')
    for old, new in zip(OLD, NEW):
        guide = guide.replace(old, new)
        (STAGE / '图表' / old).unlink()
    guide = guide.replace('完整TD网格及成本放问答页', 'TD切换时机、参数日程及成本放问答页')
    guide = guide.replace('TD三张调参图沿用175模型、35万局冻结验证',
        'TD参数与切换时机图使用原175模型的35万局冻结验证，日程图使用其中三种方案的真实训练日志')
    guide = guide.replace('误差条为五个训练种子间样本标准差。',
        'TD折线图的误差条及训练曲线阴影为五个训练种子间样本标准差，不是置信区间。')
    guide = guide.replace('用参数网格解释学习率／探索率日程', '用控制变量折线解释学习率／探索率日程')
    guide = guide.replace('置信区间和完整调参网格放备份页', '置信区间和完整调参表放备份页')
    guide = guide.replace('每格是五个训练模型的测试均值，不把10,000条游戏样本当作10,000次独立训练。',
        '图05采用控制变量折线：左列固定ε=0.002扫描α，右列固定α=0.03扫描ε，上排看平均总和、下排看256达标率；共展示9个不同配置。点为五个训练模型的测试均值，误差条为模型间样本标准差。不把10,000条游戏样本当作10,000次独立训练。完整25组交叉组合保存在复核附件中，主图没有展示全部组合。')
    guide = guide.replace('图：[TD切换时机](图表/06_TD切换时机折线图.png)。',
        '图：[TD切换时机](图表/06_TD切换时机折线图.png)。横轴是α降低的时间，三条线分别对应ε在18／24／27万局降低，完整展示9组组合；误差条为五个训练模型间样本标准差。')
    guide = guide.replace('图：[TD参数日程与结果](图表/07_TD参数日程与训练曲线.png)。',
        '图：[TD参数日程与训练曲线](图表/07_TD参数日程与训练曲线.png)。上排画实际参数日程，下排画三种日程的真实训练曲线，每点对应连续10,000局的均值，再对五个训练种子取均值；阴影为种子间样本标准差，没有平滑。下排包含训练探索动作，不能当成冻结模型测试成绩。')
    guide = guide.replace('TD的175模型验证、逐批日程、训练日志保持不变。',
        'TD的175模型验证、逐批日程、训练日志保持不变；新增折线图逐点数值和生成代码，绘图调整不改变实验结果。')
    guide = guide.replace('逐项重算；每格5训练种子均值', '逐项重算；每点5训练种子均值')
    (STAGE / '大纲.md').write_text(guide, encoding='utf-8')

    data['TD折线图/冻结验证曲线逐点数值.csv'] = csvbytes(plotrows)
    data['TD折线图/日程训练曲线逐点数值.csv'] = csvbytes(training_rows)
    data['TD折线图/生成代码.py'] = Path(__file__).read_bytes()
    audits = list(csv.DictReader(io.StringIO(data['汇总/图表核对.csv'].decode('utf-8-sig'))))
    audits = [r for r in audits if 'TD调参' not in r.get('图表', '')]
    audits.append(dict(图表='05—07 TD折线图',核对='35组×5训练种子汇总与原表一致；05为9个配置控制变量切片；06为9组完整时机；07为三种日程真实训练日志，阴影为模型间样本标准差'))
    data['汇总/图表核对.csv'] = csvbytes(audits)
    data['TD折线图/绘图说明.txt'] = (
        '05图只展示固定另一参数的两个切片，共9个不同配置；完整25组结果见汇总/TD配置汇总.csv。\n'
        '06图展示完整9组切换时机。05/06均为冻结模型、epsilon=0的2000局验证结果。\n'
        '07图下排为三种日程的训练成绩（含探索动作），每点1万局；不冒充冻结验证。\n'
        '误差条和阴影均为五个训练种子间样本标准差；无平滑。既有主榜和权重不变。\n').encode('utf-8')
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, content in data.items(): z.writestr(name, content)
    files = sorted(p for p in STAGE.rglob('*') if p.is_file())
    assert len(files) == 14 and sum(p.suffix == '.png' for p in files) == 8
    for link in re.findall(r'\]\(([^)]+)\)', guide):
        if not link.startswith('https://'): assert (STAGE / link).is_file(), link
    for name in NEW:
        with Image.open(STAGE / '图表' / name) as im: im.verify()
    with zipfile.ZipFile(archive) as z: assert z.testzip() is None
    if '--publish' not in __import__('sys').argv:
        print('Preview ready:', STAGE); return
    outputzip = BASE / 'output/大纲与素材.zip'
    tmp = outputzip.with_suffix('.tmp.zip')
    with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in files: z.write(p, (Path('大纲与素材') / p.relative_to(STAGE)).as_posix())
    with zipfile.ZipFile(tmp) as z:
        assert len(z.namelist()) == 14 and z.testzip() is None
        for p in files:
            name = (Path('大纲与素材') / p.relative_to(STAGE)).as_posix()
            assert hashlib.sha256(z.read(name)).digest() == hashlib.sha256(p.read_bytes()).digest()
    assert TARGET.resolve() == (ROOT / 'final_report_20261108/output/大纲与素材').resolve()
    assert STAGE.resolve().is_relative_to((BASE / '.build').resolve())
    shutil.move(str(TARGET), str(BACKUP))
    shutil.move(str(STAGE), str(TARGET))
    tmp.replace(outputzip)
    print('Published:', outputzip)

if __name__ == '__main__':
    main()
