"""Publish one dual-axis depth chart and consistently update the MCTS experiment."""
from pathlib import Path
from collections import Counter
import csv,gzip,hashlib,io,json,math,re,shutil,sys,zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
from PIL import Image
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];BASE=ROOT/'final_report_20261108'
TARGET=BASE/'output/大纲与素材';SNAP=BASE/'.build/深度更新前素材';STAGE=BASE/'.build/深度更新交接待发布';FIG=STAGE/'图表'
PREV=ROOT/'本地实验/完整调参_20261110';C=BASE/'.build/report-pr-20261108/checkout'
plt.rcParams.update({'font.family':'Microsoft YaHei','font.size':11,'axes.unicode_minus':False,'savefig.dpi':180,'axes.titlepad':14})
ORDER=['expectimax','td','mcts'];NAMES=['完整Expectimax','乐观TD','MCTS'];COLORS=['#306F9E','#7E0C6E','#748694']
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def csvbytes(rows):
    f=io.StringIO(newline='');w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows);return f.getvalue().encode('utf-8-sig')
def rowsbytes(data):return list(csv.DictReader(io.StringIO(data.decode('utf-8-sig'))))
def gzrows(p):return rowsbytes(gzip.decompress(Path(p).read_bytes()))
def save(fig,name):fig.tight_layout();fig.savefig(FIG/name,bbox_inches='tight');plt.close(fig)
def stats(rows):
    assert len(rows)==10000 and [int(r['seed']) for r in rows]==list(range(3000000,3010000))
    s=np.array([int(r['sum']) for r in rows]);m=np.array([int(r['max_tile']) for r in rows])
    return dict(mean_sum=float(s.mean()),max_sum=int(s.max()),success_256=float(np.mean(m>=256)),tile_counts=Counter(m.tolist()))
def main():
    status=read(OUT/'status.json');assert status['status']=='complete';assert read(OUT/'cost_status.json')['status']=='complete'
    if not SNAP.exists():shutil.copytree(TARGET,SNAP)
    for n in ['图表','演示','模板','复核数据']:(STAGE/n).mkdir(parents=True,exist_ok=True)
    for a,b in [('01_TD训练曲线.png','01_TD训练曲线.png'),('06_TD参数数值热力图.png','05_TD参数数值热力图.png'),('07_TD切换时机热力图.png','06_TD切换时机热力图.png'),('08_TD参数日程与结果.png','07_TD参数日程与结果.png')]:shutil.copy2(SNAP/'图表'/a,FIG/b)
    for n in ['完整Expectimax.gif','乐观TD.gif']:shutil.copy2(SNAP/'演示'/n,STAGE/'演示'/n)
    shutil.copy2(OUT/'MCTS.gif',STAGE/'演示/MCTS.gif');shutil.copy2(SNAP/'模板/NKU-beamer-template.zip',STAGE/'模板/NKU-beamer-template.zip')
    with zipfile.ZipFile(SNAP/'复核数据/数据与复核.zip') as z:old={n:z.read(n) for n in z.namelist()}
    selected=read(OUT/'selected.json');d=selected['depth'];assert selected['locked_before_final_evaluation']
    validation=read(OUT/'validation_results.json');confirmation=read(OUT/'confirmation_results.json');final=read(OUT/'final_results.json')[0]
    raw={k:rowsbytes(gzip.decompress(old[f'原万局/{k}_10000局.csv.gz'])) for k in ['expectimax','td']}
    raw['mcts']=gzrows(OUT/f'final_b512_d{d}_all.csv.gz');summary={k:stats(raw[k]) for k in ORDER};mc=summary['mcts']
    assert abs(mc['mean_sum']-final['mean_sum'])<1e-10 and mc['max_sum']==final['max_sum'] and abs(mc['success_256']-final['success_256'])<1e-12
    assert dict(mc['tile_counts'])=={int(k):v for k,v in final['max_tile_counts'].items()}
    vraw=[];ci_mean=[];ci_rate=[]
    for r in validation:
        rows=[]
        for off in range(0,2000,250):rows+=gzrows(OUT/f'validation/b512_d{r["depth"]}_{off:05d}.csv.gz')
        assert [int(v['seed']) for v in rows]==list(range(6500000,6502000))
        values=np.array([int(v['sum']) for v in rows]);p=np.mean([int(v['max_tile'])>=256 for v in rows])
        assert abs(values.mean()-r['mean_sum'])<1e-10 and abs(p-r['success_256'])<1e-12
        ci_mean.append(1.95996398454*values.std(ddof=1)/np.sqrt(2000))
        z=1.95996398454;den=1+z*z/2000;center=(p+z*z/4000)/den;half=z*np.sqrt(p*(1-p)/2000+z*z/(4*2000**2))/den
        ci_rate.append((center-half,center+half));vraw.extend(dict(simulations=512,depth=r['depth'],**v) for v in rows)
    cr=[]
    for r in confirmation:
        rows=gzrows(OUT/f'confirmation_b{r["simulations"]}_d{r["depth"]}_all.csv.gz')
        assert [int(v['seed']) for v in rows]==list(range(7000000,7003000))
        assert abs(np.mean([int(v['sum']) for v in rows])-r['mean_sum'])<1e-10
        assert abs(np.mean([int(v['max_tile'])>=256 for v in rows])-r['success_256'])<1e-12
        cr.extend(dict(simulations=r['simulations'],depth=r['depth'],**v) for v in rows)
    x=np.array([r['depth'] for r in validation]);y=np.array([r['mean_sum'] for r in validation]);p=np.array([r['success_256'] for r in validation]);ci=np.array(ci_mean);pc=np.array(ci_rate)
    fig,ax=plt.subplots(figsize=(11.6,6.0));right=ax.twinx();blue='#246B9E';orange='#D47B20'
    l1,=ax.plot(x,y,'o-',color=blue,lw=2,ms=4,label='平均终局总和');ax.fill_between(x,y-ci,y+ci,color=blue,alpha=.10)
    l2,=right.plot(x,p,'s--',color=orange,lw=2,ms=4,label='256达标率');right.fill_between(x,pc[:,0],pc[:,1],color=orange,alpha=.10)
    mark=ax.axvline(d,color='#6B587D',ls=':',lw=1.8,label=f'确认集选定：深度{d}')
    ax.set(xlabel='搜索深度上限（树内动作＋后续试走）',ylabel='平均终局总和',xlim=(.4,40.6),ylim=(0,math.ceil(max(y+ci)/50)*50),xticks=[1,3,6,9,12,16,20,24,28,32,40])
    right.set(ylabel='256达标率',ylim=(0,min(1,math.ceil(pc[:,1].max()*10)/10+.05)));right.yaxis.set_major_formatter(PercentFormatter(1))
    ax.yaxis.label.set_color(blue);ax.tick_params(axis='y',colors=blue);right.yaxis.label.set_color(orange);right.tick_params(axis='y',colors=orange)
    ax.spines['top'].set_visible(False);right.spines['top'].set_visible(False);ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
    ax.set_title('固定每步512次模拟：搜索深度敏感性');ax.legend(handles=[l1,l2,mark],loc='lower right',frameon=False,fontsize=11)
    save(fig,'04_MCTS搜索深度双轴曲线.png')
    # Updated four main metrics, using the same original 10,000 test seeds.
    fig,axes=plt.subplots(1,3,figsize=(14,4.6));xx=np.arange(3)
    for ax,key,title in [(axes[0],'mean_sum','平均终局总和'),(axes[1],'max_sum','最高终局总和'),(axes[2],'success_256','256达标率（%）')]:
        vals=[summary[k][key]*(100 if key=='success_256' else 1) for k in ORDER];ax.bar(xx,vals,color=COLORS,width=.6);ax.set_xticks(xx,NAMES);ax.set_title(title)
        ax.set_ylim(0,115 if key=='success_256' else max(vals)*1.18);ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
        for i,v in enumerate(vals):ax.text(i,v+max(vals)*.025,f'{v:.2f}%' if key=='success_256' else f'{v:.3f}' if key=='mean_sum' else str(int(v)),ha='center')
    save(fig,'02_万局结果总览.png')
    tiles=sorted({v for r in summary.values() for v in r['tile_counts']})
    colors_by_tile={8:'#EDF0F3',16:'#D9DEE3',32:'#ACB8C3',64:'#92BDCE',128:'#507FA5',256:'#B889BB',512:'#7E0C6E',1024:'#D5A42C'}
    palette=[colors_by_tile[t] for t in tiles]
    fig,ax=plt.subplots(figsize=(10.6,4.1));left=np.zeros(3)
    for tile,color in zip(tiles,palette):
        vals=np.array([summary[k]['tile_counts'].get(tile,0)/100 for k in ORDER]);ax.barh(xx,vals,left=left,color=color,height=.55,label=str(tile))
        for i,v in enumerate(vals):
            if v>=6:ax.text(left[i]+v/2,i,f'{v:.2f}%',ha='center',va='center',color='white' if tile in [128,512] else '#252525')
        left+=vals
    assert np.allclose(left,100);ax.set(yticks=xx,yticklabels=NAMES,xlim=(0,100),xlabel='对局比例（%）');ax.invert_yaxis();ax.set_title('终局最大块分布',pad=47)
    ax.legend(title='终局最大块',ncol=len(tiles),frameon=False,loc='lower center',bbox_to_anchor=(.5,1.01),fontsize=9);save(fig,'03_最大块分布.png')
    # Offline preparation is unchanged; all three online policies are remeasured together.
    previous=read(PREV/'export_summary.json');offline={r['method']:r for r in previous['cost']};online=read(OUT/'online_cost_results.json');cost=[]
    for k in ORDER:
        rr=sorted([r for r in online if r['method']==k],key=lambda r:r['trial']);assert len(rr)==3
        for i,r in enumerate(rr):
            assert r['affinity']==[0] and r['shared_board_test']['calls']==96 and len(r['episodes'])==3
            assert [v['seed'] for v in r['episodes']]==list(range(6800000,6800003))
            if i:assert [(v['sum'],v['steps']) for v in r['episodes']]==[(v['sum'],v['steps']) for v in rr[0]['episodes']]
        latency=[r['shared_board_test']['mean_us'] for r in rr]
        cost.append(dict(**{key:offline[k][key] for key in ['method','offline_median_s','offline_min_s','offline_max_s','offline_peak_rss_MiB','persistent_artifact_MiB']},
            ready_load_median_s=float(np.median([r['load_ready']['wall_seconds'] for r in rr])),choose_mean_us_median=float(np.median(latency)),choose_mean_us_min=min(latency),choose_mean_us_max=max(latency),
            online_peak_rss_MiB=max(r['peak_rss_bytes'] for r in rr)/2**20,mean_episode_wall_s_median=float(np.median([r['end_to_end']['wall_seconds']/3 for r in rr])),
            end_to_end_cpu_ms_per_step_median=float(np.median([r['end_to_end']['cpu_seconds']/r['end_to_end']['total_steps']*1000 for r in rr]))))
    fig,axes=plt.subplots(1,3,figsize=(14,4.8))
    for ax,key,title,log in [(axes[0],'offline_median_s','首次训练／建表与保存（秒）',False),(axes[1],'choose_mean_us_median','共同棋盘平均决策耗时（微秒）',True),(axes[2],'online_peak_rss_MiB','推理进程峰值RSS（MiB）',False)]:
        vals=[r[key] for r in cost];ax.bar(xx,vals,color=COLORS,width=.6);ax.set_xticks(xx,NAMES);ax.set_title(title);ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
        if log:ax.set_yscale('log');ax.set_ylim(min(vals)*.35,max(vals)*3.5)
        else:ax.set_ylim(0,max(vals)*1.22)
        for i,v in enumerate(vals):ax.text(i,v*1.2 if log else v+max(vals)*.035,f'{v:.2f}' if key!='online_peak_rss_MiB' else f'{v:.1f}',ha='center')
    save(fig,'08_统一成本对比.png')
    guide=(SNAP/'大纲.md').read_text(encoding='utf-8');a=guide.index('主结果沿用');b=guide.index('## 展示安排')
    intro=f'''当前主结果均为每方法10,000局：完整Expectimax与TD沿用原记录，MCTS更新为每步512次模拟、深度{d}，重新测试相同万局种子。MCTS的选参、正式评测、演示和在线成本均已更新；TD调参与原训练曲线保留。

## 文件怎么用与图表核对

主目录共14个文件：8张PNG、3个原版游戏GIF、一份大纲、一份模板、一份复核附件。图片只保留一份。

| 用途 | 文件 |
| --- | --- |
| 主结果与演示 | 01 TD训练曲线、02 万局结果、03 最大块分布；三个原版界面GIF |
| 方法内调参讨论 | 04 MCTS搜索深度双轴曲线；05 TD参数数值、06 切换时机、07 渐变日程 |
| 成本与核查 | 08 统一成本图、本文成本表；[数据与复核](复核数据/数据与复核.zip) |

五分钟展示优先使用04曲线和05中的主要结论，完整TD网格及成本放问答页。MCTS曲线由25个深度、每点2,000局重算，左轴为平均总和，右轴为256达标率；蓝色阴影为均值的近似95%区间，橙色阴影为达标率的Wilson 95%区间。双轴两条线的交点没有统计含义。最终选参使用下文预先固定的综合效用与独立确认集，竖线不一定落在曲线的单项最高点。

主结果图逐项核对三万行原始记录。TD三张调参图沿用175模型、35万局冻结验证；误差条为五个训练种子间样本标准差。MCTS批量实验使用核对动作和随机数状态的C++加速器，成本测量采用原Python智能体。图表数值已经核对，抽样误差与候选选择范围仍应在解释中保留。

'''
    guide=guide[:a]+intro+guide[b:]
    guide=guide.replace('用新MCTS图简述“模拟更多有帮助，搜索更深未必”','用双轴曲线说明深度对平均总和与达标率的不同影响').replace('原万局主结果与结论','万局主结果与结论').replace('原万局主表','万局主表')
    guide=guide.replace('| 每步模拟次数B | 128 |','| 每步模拟次数B | 512 |').replace('| 深度上限h | 12 |',f'| 深度上限h | {d} |')
    a=guide.index('### 二维网格：');b=guide.index('## 方法三',a)
    text='''### 固定模拟预算，单独扫描搜索深度

前一轮扫描支持继续考察每步512次模拟。本轮固定这一预算和全部启发式、UCT、rollout参数，深度取1—20的每个整数，再加22、24、28、32、40，共25点。每点2,000局，使用共同验证种子6,500,000—6,501,999；其中深度3、6、9、12、18、24沿用完全相同的旧记录，其余19点新跑38,000局。曲线合计50,000局，不把复用数据写成全部新运行。

图：[搜索深度双轴曲线](图表/04_MCTS搜索深度双轴曲线.png)。深度上限包含树内动作与后续试走；每个动作的模拟次数固定，因此较深时表现下降不能解释成“模拟次数变少”。较长的简单试走会增加对试走策略的依赖，随机落块与叶子估值也会影响结果；这些是解释机制，本轮没有分别隔离各机制。

选择规则在新增结果出现前固定，沿用完整Expectimax的终局目标：

\\[
J(h)=\\overline S(h)+256\\widehat P_h(M\\ge256).
\\]

这是同时考虑总和与达标率的一种明确权衡，并非只取任意一条曲线最高点。先取验证集J前三名，再加入平均总和与达标率各自最高的深度，去重后固定候选。用新种子7,000,000—7,002,999，每候选3,000局确认；原128／12配置作为参照。确认集按J选择最终配置，之后锁定参数，再做独立的正式万局评测。确认集参与选参，不把它称为最终无偏测试集。

| 模拟次数 | 深度 | 确认集平均总和 | ≥256 | 综合效用J |
| ---: | ---: | ---: | ---: | ---: |
'''
    for r in sorted(confirmation,key=lambda r:r['objective'],reverse=True):text+=f"| {r['simulations']} | {r['depth']} | {r['mean_sum']:.3f} | {r['success_256']:.2%} | {r['objective']:.3f} |\n"
    finalists=sorted([r for r in confirmation if r['simulations']==512],key=lambda r:(-r['objective'],r['depth']))
    second=finalists[1];a1=gzrows(OUT/f'confirmation_b512_d{d}_all.csv.gz');a2=gzrows(OUT/f'confirmation_b512_d{second["depth"]}_all.csv.gz')
    jdiff=np.array([int(a['sum'])+256*(int(a['max_tile'])>=256)-int(b['sum'])-256*(int(b['max_tile'])>=256) for a,b in zip(a1,a2)])
    jmargin=1.95996398454*jdiff.std(ddof=1)/np.sqrt(3000)
    text+=f"\n深度{d}与次高综合效用的深度{second['depth']}差距很小：确认集配对效用差{jdiff.mean():+.3f}，探索性近似95%区间［{jdiff.mean()-jmargin:.3f}，{jdiff.mean()+jmargin:.3f}］，未作多重比较校正。此处按预定规则选取点估计较高者用于后续实验，不能据此证明它显著优于所有相邻深度。\n"
    baseold=rowsbytes(gzip.decompress(old['原万局/mcts_10000局.csv.gz']));oldstat=stats(baseold)
    paired=np.array([int(n['sum'])-int(o['sum']) for n,o in zip(raw['mcts'],baseold)]);margin=1.95996398454*paired.std(ddof=1)/100
    text+=f"\n最终采用**512次模拟、深度{d}**。正式万局平均总和{mc['mean_sum']:.3f}、256达标率{mc['success_256']:.2%}；原128／12在相同种子下分别为{oldstat['mean_sum']:.3f}、{oldstat['success_256']:.2%}。平均总和配对差为{paired.mean():+.3f}，近似95%区间［{paired.mean()-margin:.3f}，{paired.mean()+margin:.3f}］。模拟预算同时由128增加到512，所以这项最终提升来自预算和深度的共同改变，不能全部归功于深度。\n\n"
    text+='这只是固定512次模拟、当前试走策略与估值函数下，在所测深度和种子范围内的选择。曲线局部起伏包含抽样误差，不能宣称找到全局最优。MCTS没有训练权重；更新的是运行配置。\n\n'
    guide=guide[:a]+text+guide[b:]
    demo=read(OUT/'demo_receipt.json');dr=demo['result'];trace=read(OUT/'MCTS_逐步记录.json')['records']
    assert dr['sum']==mc['max_sum'] and trace[-1]['board_sum']==dr['sum'] and trace[-1]['max_tile']==dr['max_tile'] and len(trace)-1==dr['steps']
    guide=re.sub(r'\| MCTS \| \[完整对局\]\(演示/MCTS.gif\).*?\n',f"| MCTS | [完整对局](演示/MCTS.gif) | {dr['sum']} | {dr['max_tile']} | {dr['steps']} | {dr['seed']} | {demo['gif_duration_seconds']:.2f}秒 |\n",guide)
    guide=guide.replace('各自原万局测试中','各自当前万局测试中').replace('## 最终结果：原来的每方法1万局','## 最终结果：每方法1万局')
    guide=re.sub(r'\| MCTS \| 282\.013 \| 636 \| 34\.96% \|',f"| MCTS | {mc['mean_sum']:.3f} | {mc['max_sum']} | {mc['success_256']:.2%} |",guide)
    a=guide.index('| 方法 | 最大块16');b=guide.index('分布中的类别互斥',a)
    distribution='| 方法 | '+' | '.join('最大块'+str(t) for t in tiles)+' |\n| --- | '+' | '.join('---:' for t in tiles)+' |\n'
    for i,k in enumerate(ORDER):distribution+='| '+NAMES[i]+' | '+' | '.join(f"{summary[k]['tile_counts'].get(t,0)/100:.2f}%" for t in tiles)+' |\n'
    guide=guide[:a]+distribution+'\n'+guide[b:]
    at_least512=sum(n for t,n in mc['tile_counts'].items() if t>=512)/100
    guide=guide.replace('MCTS为0.02%',f'MCTS为{at_least512:.2f}%')
    guide=guide.replace('## 统一成本对比：替换原历史计时','## 统一成本对比：采用更新后的MCTS配置')
    for r in cost:
        name={'expectimax':'完整Expectimax','td':'乐观TD','mcts':'MCTS'}[r['method']]
        guide=re.sub(r'\| '+name+r' \| [\d.]+ \| [\d.]+ \| [\d.]+ \| [\d.]+ \| [\d.]+ \|\n',f"| {name} | {r['offline_median_s']:.3f} | {r['ready_load_median_s']:.4f} | {r['choose_mean_us_median']:.2f} | {r['online_peak_rss_MiB']:.1f} | {r['persistent_artifact_MiB']:.3f} |\n",guide)
        # Restrict the secondary cost table replacement to the cost section.
        a=guide.index('## 统一成本对比');g1,g2=guide[:a],guide[a:]
        g2=re.sub(r'\| '+name+r' \| [\d.]+ \| [\d.]+ \| [\d.]+ \|\n',f"| {name} | {r['mean_episode_wall_s_median']:.4f} | {r['end_to_end_cpu_ms_per_step_median']:.4f} | {r['offline_peak_rss_MiB']:.1f} |\n",g2);guide=g1+g2
    guide=guide.replace('每次实验循环3遍，共288次选择','每次实验测一遍，共96次选择，三次合计288次选择').replace('相同10个新种子','相同3个新种子6,800,000—6,800,002')
    guide=guide.replace('共同棋盘来自原三个演示轨迹','共同棋盘来自当前三个演示轨迹（包括更新的MCTS演示）')
    guide=guide.replace('之前42.25秒建表、64.30秒训练来自不同环境和计时边界，不能直接比较，本节以重新实测为准。','三种智能体的在线成本在本轮深度实验及演示完成后统一重新测量。Expectimax与TD的离线产物没有改变，首次准备成本沿用上一轮同机、同环境、单核的三次实测；不重新训练或建表。MCTS仍无离线训练，在线成本使用最终512次模拟及选定深度，不能沿用旧128／12的耗时。')
    a=guide.index('## 复核数据与实验调度');b=guide.index('## 参考文献',a)
    guide=guide[:a]+f'''## 复核数据与实验调度

[数据与复核.zip](复核数据/数据与复核.zip)包含当前三份万局记录、MCTS的50,000局深度扫描、{len(cr):,}局确认集、最终配置、演示轨迹及核对记录；TD的175模型验证、逐批日程、训练日志保持不变。旧MCTS万局仅放在历史参照目录，用于配对比较。

本机10核20线程。深度实验用10个单线程进程，每个进程固定到不同物理核心的一个逻辑CPU，250局一个任务块，较深任务优先。重复的旧验证记录直接复用。选定后重新评测万局，原Pygame窗口实跑并捕获一局最好样本；全部评测完成后再串行测三种原实现的在线成本。确认集用于最终选参，正式万局用于报告最终表现。

调参程序、原实现、C++核与动作／随机数状态检查记录都保留在附件；批量加速核的运行时间不冒充原Python智能体的成本。数据中保存未四舍五入的数值。运行脚本保留本地路径，复跑前按说明恢复项目与依赖。

''' +guide[b:]
    for oldname,newname in [('06_TD参数数值热力图.png','05_TD参数数值热力图.png'),('07_TD切换时机热力图.png','06_TD切换时机热力图.png'),('08_TD参数日程与结果.png','07_TD参数日程与结果.png'),('09_统一成本对比.png','08_统一成本对比.png')]:guide=guide.replace(oldname,newname)
    guide=guide.replace('网格用的MCTS C++加速器','深度实验用的MCTS C++加速器')
    (STAGE/'大纲.md').write_text(guide,encoding='utf-8')
    config=(C/'config/mcts.yaml').read_text(encoding='utf-8');config=re.sub(r'simulations: \d+','simulations: 512',config);config=re.sub(r'depth: \d+',f'depth: {d}',config)
    (OUT/'selected_mcts.yaml').write_text(config,encoding='utf-8')
    # Keep only current material at top level; detailed evidence stays inside one attachment.
    data=dict(old);oldmc=data.pop('原万局/mcts_10000局.csv.gz');data['历史参照/MCTS_128x12_10000局.csv.gz']=oldmc;data['原万局/mcts_10000局.csv.gz']=gzip.compress(csvbytes(raw['mcts']),mtime=0)
    for n in list(data):
        if n in ['逐局数据/MCTS网格逐局.csv.gz','逐局数据/MCTS独立保留集逐局.csv.gz','汇总/MCTS网格汇总.csv'] or n in ['设计与核对/mcts_design.json','设计与核对/mcts_status.json']:data.pop(n)
    for n in ['汇总/成本主表.csv','汇总/共同棋盘逐次延迟.csv','汇总/真实整局成本.csv','设计与核对/shared_board_bank.json','设计与核对/cost_all_results.json','设计与核对/cost_design.json','设计与核对/cost_status.json','汇总/图表核对.csv']:
        if n in data:data['历史参照/'+n]=data.pop(n)
    prior_phases=rowsbytes(data.pop('汇总/成本阶段计时.csv'))
    data['历史参照/旧成本阶段计时.csv']=csvbytes(prior_phases)
    current_phases=[r for r in prior_phases if r['phase']!='load_ready']
    current_phases.extend(dict(method=r['method'],trial=r['trial'],phase='load_ready',**r['load_ready']) for r in online)
    data['汇总/成本阶段计时.csv']=csvbytes(current_phases)
    prior_cost=read(PREV/'cost_all_results.json')
    current_cost=[r for r in prior_cost if not r['phase'].startswith('online_')]+online
    data['设计与核对/cost_all_results.json']=(json.dumps(current_cost,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    current_design=read(PREV/'cost_design.json');current_design.update(seed_range=[6800000,6800002],board_rounds_per_repetition=1,
        mcts_config=dict(simulations=512,depth=d),offline_note='Expectimax and TD unchanged; previous same-environment preparation measurements retained',
        online_note='all three online methods remeasured after the depth study and original-window demo')
    data['设计与核对/cost_design.json']=(json.dumps(current_design,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    data['设计与核对/shared_board_bank.json']=(OUT/'shared_board_bank.json').read_bytes()
    data['设计与核对/cost_status.json']=(OUT/'cost_status.json').read_bytes()
    if '设计与核对/holdout_design.json' in data:data['历史参照/上一轮候选设计.json']=data.pop('设计与核对/holdout_design.json')
    configkey='实现依据/final_report_20261108/.build/report-pr-20261108/checkout/config/mcts.yaml'
    if configkey in data:data['历史参照/旧MCTS配置.yaml']=data[configkey]
    data[configkey]=config.encode('utf-8')
    if '汇总/独立保留集汇总.csv' in data:
        rr=rowsbytes(data.pop('汇总/独立保留集汇总.csv'));data['汇总/TD独立保留集汇总.csv']=csvbytes([r for r in rr if r['method']=='TD'])
    statsrows=[dict(方法=NAMES[i],局数=10000,平均终局总和=summary[k]['mean_sum'],最高终局总和=summary[k]['max_sum'],达标率256=summary[k]['success_256']) for i,k in enumerate(ORDER)]
    data['图表汇总/原万局主结果.csv']=csvbytes(statsrows)
    data['图表汇总/原万局最大块分布.csv']=csvbytes([dict(方法=NAMES[i],最大块=t,局数=summary[k]['tile_counts'].get(t,0),比例=summary[k]['tile_counts'].get(t,0)/10000) for i,k in enumerate(ORDER) for t in tiles])
    data['逐局数据/MCTS深度扫描.csv.gz']=gzip.compress(csvbytes(vraw),mtime=0);data['逐局数据/MCTS确认集.csv.gz']=gzip.compress(csvbytes(cr),mtime=0)
    data['汇总/MCTS深度扫描.csv']=csvbytes(validation);data['汇总/MCTS确认集.csv']=csvbytes(confirmation);data['汇总/成本主表.csv']=csvbytes(cost)
    data['汇总/共同棋盘逐次延迟.csv']=csvbytes([dict(method=r['method'],trial=r['trial'],**v) for r in online for v in r['shared_board_rows']])
    data['汇总/真实整局成本.csv']=csvbytes([dict(method=r['method'],trial=r['trial'],**v) for r in online for v in r['episodes']])
    for n in ['design.json','equivalence.json','confirmation_design.json','selected.json','status.json','final_results.json','online_cost_results.json','shared_board_bank.json','cost_status.json','demo_receipt.json','MCTS_逐步记录.json','selected_mcts.yaml']:data['MCTS深度更新/'+n]=(OUT/n).read_bytes()
    for n in ['run_study.py','pipeline.py','record_demo.py','policy_server.py','benchmark_online.py','export_update.py']:data['MCTS深度更新/运行代码/'+n]=(OUT/n).read_bytes()
    data['汇总/图表核对.csv']=csvbytes([dict(图表='04 MCTS深度双轴',核对='25点各2000行，均值/成功率/近似均值区间/Wilson区间重算；选择来自独立确认集'),dict(图表='02—03当前主结果',核对='EX与TD原记录，MCTS新10000局；无漏种子，分布合计10000'),dict(图表='08当前成本',核对='在线三方法全部重测，单逻辑CPU串行3次；离线EX和TD原实测不变'),dict(图表='MCTS GIF',核对='原游戏实际窗口，终局/种子/步数与当前万局最好样本一致')])
    with zipfile.ZipFile(STAGE/'复核数据/数据与复核.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for n,content in data.items():z.writestr(n,content)
    for link in re.findall(r'\]\(([^)]+)\)',guide):
        if not link.startswith('https://'):assert (STAGE/link).is_file(),link
    files=sorted(p for p in STAGE.rglob('*') if p.is_file());assert len(files)==14 and sum(p.suffix=='.png' for p in files)==8
    for p in files:
        if p.suffix=='.png':
            with Image.open(p) as im:im.verify()
        if p.suffix=='.zip':
            with zipfile.ZipFile(p) as z:assert z.testzip() is None
    result=dict(selected=selected,final=final,cost=cost,files=14,png=8,validation_games=len(vraw),confirmation_games=len(cr),demo=demo)
    (OUT/'export_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if '--preview' in sys.argv:print(json.dumps(dict(preview=str(STAGE),selected_depth=d,final=final,cost=cost),ensure_ascii=True));return
    archive=BASE/'output/大纲与素材.zip';tmp=archive.with_suffix('.tmp.zip')
    with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files:z.write(p,(Path('大纲与素材')/p.relative_to(STAGE)).as_posix())
    with zipfile.ZipFile(tmp) as z:
        assert len(z.namelist())==14 and z.testzip() is None
        for p in files:assert hashlib.sha256(z.read((Path('大纲与素材')/p.relative_to(STAGE)).as_posix())).digest()==hashlib.sha256(p.read_bytes()).digest()
    backup=BASE/'.build/深度发布前素材';assert not backup.exists()
    assert TARGET.resolve()==(BASE/'output/大纲与素材').resolve() and TARGET.resolve().is_relative_to(ROOT.resolve())
    assert STAGE.resolve().is_relative_to((BASE/'.build').resolve())
    shutil.move(str(TARGET),str(backup));shutil.move(str(STAGE),str(TARGET));tmp.replace(archive)
    # Update only the production parameter file; no algorithm changes or remote publication.
    (OUT/'previous_mcts.yaml').write_text((C/'config/mcts.yaml').read_text(encoding='utf-8'),encoding='utf-8',newline='\n');(C/'config/mcts.yaml').write_text(config,encoding='utf-8',newline='\n')
    print(json.dumps(dict(archive=str(archive),bytes=archive.stat().st_size,selected_depth=d,final=final),ensure_ascii=True))
if __name__=='__main__':main()
