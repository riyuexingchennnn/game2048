"""Run demo capture and serial production-cost measurements after evaluation."""
from pathlib import Path
import json,subprocess,sys,time
OUT=Path(__file__).resolve().parent
while True:
    path=OUT/'status.json'
    if path.exists() and json.loads(path.read_text(encoding='utf-8')).get('status')=='complete':break
    time.sleep(10)
if not (OUT/'demo_receipt.json').exists():subprocess.run([sys.executable,'-u',str(OUT/'record_demo.py')],check=True)
subprocess.run(['wsl.exe','-d','Ubuntu','--','/home/panliang/.local/share/game2048-eval-20261110/bin/python','-u',
    '/mnt/c/Users/31245/Desktop/game2048-master/本地实验/MCTS深度优化_20261110/benchmark_online.py'],check=True)
print('DEPTH_UPDATE_ALL_RUNS_COMPLETE',flush=True)
