"""Capture actual original Pygame display while selected MCTS plays live."""
from pathlib import Path
import csv,gzip,hashlib,json,os,subprocess,sys,time
os.environ['PYGAME_HIDE_SUPPORT_PROMPT']='1'
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];C=ROOT/'final_report_20261108/.build/report-pr-20261108/checkout'
sys.path.insert(0,str(C))
import numpy as np,pygame
from PIL import Image
from game2048.wrappers.env import ExperimentEnv
from game2048.core import merge_score,move_board
def main():
    selected=json.loads((OUT/'selected.json').read_text(encoding='utf-8'));d=selected['depth']
    with gzip.open(OUT/f'final_b512_d{d}_all.csv.gz','rt',encoding='utf-8') as f:rows=list(csv.DictReader(f))
    chosen=max(rows,key=lambda r:(int(r['sum']),-int(r['seed'])));seed=int(chosen['seed'])
    wslscript='/mnt/c/Users/31245/Desktop/game2048-master/本地实验/MCTS深度优化_20261110/policy_server.py'
    log=(OUT/'demo_policy.log').open('w',encoding='utf-8')
    proc=subprocess.Popen(['wsl.exe','-d','Ubuntu','--','/home/panliang/.local/share/game2048-eval-20261110/bin/python','-u',wslscript,str(seed)],
        stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=log,text=True,encoding='utf-8',bufsize=1,creationflags=subprocess.CREATE_NO_WINDOW)
    assert json.loads(proc.stdout.readline())==dict(ready=True,seed=seed,simulations=512,depth=d)
    env=ExperimentEnv();env.render_mode='human';env.metadata=dict(env.metadata,render_fps=24)
    frames=[];records=[];total_merge=0;started=time.perf_counter()
    def capture():
        assert pygame.display.get_surface() is env.window
        frames.append(Image.fromarray(np.transpose(pygame.surfarray.array3d(env.window),(1,0,2))))
    try:
        obs,info=env.reset(seed=seed);pygame.display.set_caption(f'2048 - MCTS 512/{d} - seed {seed}');capture()
        records.append(dict(step=0,action=None,board=[int(v) for v in obs.flat],board_sum=int(obs.sum()),max_tile=int(obs.max()),merge_score=0))
        while info['legal_actions']:
            board=tuple(int(v) for v in obs.flat);proc.stdin.write(json.dumps(dict(board=board))+'\n');proc.stdin.flush()
            action=json.loads(proc.stdout.readline())['action'];assert action in info['legal_actions'];total_merge+=merge_score(board,action)
            obs,_,done,truncated,info=env.step(action);assert not truncated and sum(move_board(board,action))==sum(board)
            capture();records.append(dict(step=len(records),action=action,board=[int(v) for v in obs.flat],board_sum=int(obs.sum()),max_tile=int(obs.max()),merge_score=total_merge))
            if done:break
        result=dict(seed=seed,sum=int(obs.sum()),max_tile=int(obs.max()),steps=len(records)-1)
        for k,v in result.items():assert int(chosen[k])==v,(k,v,chosen[k])
        durations=[40]*len(frames);durations[0]=700;durations[-1]=2200
        path=OUT/'MCTS.gif';frames[0].save(path,save_all=True,append_images=frames[1:],duration=durations,loop=0,disposal=2,optimize=False)
        (OUT/'MCTS_逐步记录.json').write_text(json.dumps(dict(method='mcts',simulations=512,depth=d,seed=seed,records=records),ensure_ascii=False)+'\n',encoding='utf-8')
        receipt=dict(result=result,simulations=512,depth=d,frames=len(frames),gif_duration_seconds=sum(durations)/1000,
            renderer='unchanged Game2048Env._render_frame, actual displayed Pygame surface',record_seconds=time.perf_counter()-started,
            policy='repository Python MCTS; every action and RNG state checked against native kernel during the complete game',
            gif_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        (OUT/'demo_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(receipt),flush=True)
    finally:
        try:proc.stdin.write('{"quit":true}\n');proc.stdin.flush()
        except (OSError,BrokenPipeError):pass
        proc.wait(timeout=10);log.close();env.close()
if __name__=='__main__':main()
