"""Selected MCTS policy for the unmodified Windows game renderer."""
from pathlib import Path
import importlib.util,json,os,sys
os.environ['PYGAME_HIDE_SUPPORT_PROMPT']='1'
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1]
spec=importlib.util.spec_from_file_location('configured_mcts',ROOT/'本地实验/调参对照_20261110/run_mcts_parameters.py')
M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
selected=json.loads((OUT/'selected.json').read_text(encoding='utf-8'));seed=int(sys.argv[1])
agent=M.Configured(dict(simulations=512,depth=selected['depth']));agent.seed(seed+100000)
reference=M.MCTSAgent(M.MCTSConfig(simulations=512,depth=selected['depth']));reference.rng.seed(seed+100000)
print(json.dumps(dict(ready=True,seed=seed,simulations=512,depth=selected['depth'])),flush=True)
for line in sys.stdin:
    request=json.loads(line)
    if request.get('quit'):break
    board=tuple(request['board']);action=reference.choose(board)
    assert agent.choose(board)==action,'full-demo action mismatch'
    assert agent.getstate()==reference.rng.getstate(),'full-demo RNG-state mismatch'
    print(json.dumps(dict(action=action)),flush=True)
