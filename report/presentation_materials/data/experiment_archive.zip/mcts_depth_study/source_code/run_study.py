"""Dense fixed-budget depth study, confirmation, locked final evaluation."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
os.environ['PYGAME_HIDE_SUPPORT_PROMPT']='1'
from pathlib import Path
import csv,gzip,hashlib,importlib.util,json,multiprocessing as mp,time
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1]
spec=importlib.util.spec_from_file_location('configured_mcts',ROOT/'本地实验/调参对照_20261110/run_mcts_parameters.py')
M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
DEPTHS=list(range(1,21))+[22,24,28,32,40];CHUNK=250

def dump(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');tmp.replace(path)
def readrows(path):
    with gzip.open(path,'rt',encoding='utf-8') as f:return list(csv.DictReader(f))
def writerows(path,rows):
    path.parent.mkdir(exist_ok=True,parents=True);tmp=path.with_suffix('.tmp')
    with gzip.open(tmp,'wt',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    tmp.replace(path)
def init():
    rank=mp.current_process()._identity[0]-1
    os.sched_setaffinity(0,{2*(rank%10)})
def job(task):
    phase,b,d,offset,base=task;path=OUT/phase/f'b{b}_d{d}_{offset:05d}.csv.gz'
    if path.exists():return dict(phase=phase,budget=b,depth=d,offset=offset,reused=True)
    if phase=='validation' and d in [3,6,9,12,18,24]:
        source=ROOT/f'本地实验/完整调参_20261110/mcts/b512_d{d}_{offset//500*500:04d}.csv.gz'
        rows=readrows(source)[offset%500:offset%500+CHUNK];reused=True
    else:
        agent=M.Configured(dict(simulations=b,depth=d));rows=[M.play_episode(agent,seed=seed) for seed in range(base+offset,base+offset+CHUNK)];reused=False
    assert [int(r['seed']) for r in rows]==list(range(base+offset,base+offset+CHUNK))
    writerows(path,rows);return dict(phase=phase,budget=b,depth=d,offset=offset,reused=reused)
def collect(phase,b,d,n,base):
    rows=[]
    for off in range(0,n,CHUNK):rows+=readrows(OUT/phase/f'b{b}_d{d}_{off:05d}.csv.gz')
    rows=[{k:(v.lower()=='true' if k=='reached_256' else int(v)) for k,v in r.items()} for r in rows]
    assert [r['seed'] for r in rows]==list(range(base,base+n))
    sums=[r['sum'] for r in rows];p=sum(r['max_tile']>=256 for r in rows)/n
    result=dict(simulations=b,depth=d,games=n,seed_range=[base,base+n-1],mean_sum=sum(sums)/n,success_256=p,
        objective=sum(sums)/n+256*p,max_sum=max(sums),mean_steps=sum(r['steps'] for r in rows)/n,
        max_tile_counts={str(v):sum(r['max_tile']==v for r in rows) for v in sorted({r['max_tile'] for r in rows})})
    if phase!='validation':writerows(OUT/f'{phase}_b{b}_d{d}_all.csv.gz',rows)
    return result
def run_phase(phase,configs,n,base):
    tasks=sorted([(phase,b,d,o,base) for b,d in configs for o in range(0,n,CHUNK)],key=lambda t:t[1]*t[2],reverse=True)
    started=time.perf_counter();done=0
    with mp.get_context('fork').Pool(10,initializer=init) as pool:
        for r in pool.imap_unordered(job,tasks,chunksize=1):
            done+=1;dump(OUT/'status.json',dict(status='running',phase=phase,chunks_done=done,total_chunks=len(tasks),seconds=time.perf_counter()-started))
            if done%8==0:print(json.dumps(dict(phase=phase,done=done,total=len(tasks),seconds=time.perf_counter()-started)),flush=True)
    results=[collect(phase,b,d,n,base) for b,d in configs];dump(OUT/f'{phase}_results.json',results);return results
def main():
    OUT.mkdir(exist_ok=True,parents=True)
    dump(OUT/'design.json',dict(depths=DEPTHS,simulations=512,validation_games_per_depth=2000,validation_seed_range=[6500000,6501999],
        reused_validation_depths=[3,6,9,12,18,24],confirmation_games_per_config=3000,confirmation_seed_range=[7000000,7002999],
        final_games=10000,final_seed_range=[3000000,3009999],workers=10,chunk_games=CHUNK,affinity='one hardware thread per physical core',
        selection='validation top3 by mean_sum+256*success_256, plus best mean and best success; independent confirmation selects maximum objective; ties prefer smaller depth',
        objective='E[terminal sum + 256*I(max_tile>=256)]',original_reference=dict(simulations=128,depth=12),
        rules='original Gym environment, natural termination, spawn2 probability0.9, unchanged rewards and heuristics',no_training=True))
    M.Configured(dict());trace=json.loads((ROOT/'final_report_20261108/output/原版界面汇报素材/乐观TD_逐步记录.json').read_text(encoding='utf-8'))['records']
    for d in DEPTHS:
        fast=M.Configured(dict(simulations=512,depth=d));ref=M.MCTSAgent(M.MCTSConfig(simulations=512,depth=d))
        for i in [10,150]:
            board=tuple(trace[i]['board']);fast.seed(8100000+i);ref.rng.seed(8100000+i)
            assert fast.choose(board)==ref.choose(board),(d,i,'action')
            assert fast.getstate()==ref.rng.getstate(),(d,i,'rng')
    dump(OUT/'equivalence.json',dict(configurations=len(DEPTHS),action_rng_checks=2*len(DEPTHS),passed=True,
        native_sha256=hashlib.sha256((M.C/'report/benchmark10000/native_mcts.cpp').read_bytes()).hexdigest()))
    validation=run_phase('validation',[(512,d) for d in DEPTHS],2000,6500000)
    chosen={r['depth'] for r in sorted(validation,key=lambda r:(-r['objective'],r['depth']))[:3]}
    chosen.add(max(validation,key=lambda r:r['mean_sum'])['depth']);chosen.add(max(validation,key=lambda r:r['success_256'])['depth'])
    configs=[(128,12)]+[(512,d) for d in sorted(chosen)]
    dump(OUT/'confirmation_design.json',dict(configurations=configs,selection_frozen_before_confirmation=True))
    confirm=run_phase('confirmation',configs,3000,7000000)
    best=sorted([r for r in confirm if r['simulations']==512],key=lambda r:(-r['objective'],r['depth']))[0]
    dump(OUT/'selected.json',dict(**best,selection_metric='mean_sum+256*success_256',locked_before_final_evaluation=True))
    print(json.dumps(dict(selected=best)),flush=True)
    final=run_phase('final',[(512,best['depth'])],10000,3000000)
    dump(OUT/'status.json',dict(status='complete',depths=len(DEPTHS),validation_games=50000,new_validation_games=38000,
        confirmation_games=len(configs)*3000,final_games=10000,selected=final[0]))
    print('DENSE_DEPTH_STUDY_COMPLETE',flush=True)
if __name__=='__main__':main()
