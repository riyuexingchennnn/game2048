"""Remeasure all three production policies on identical boards, serial fresh workers."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
os.environ['PYGAME_HIDE_SUPPORT_PROMPT']='1'
from pathlib import Path
import argparse,json,resource,subprocess,sys,time
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];C=ROOT/'final_report_20261108/.build/report-pr-20261108/checkout'
sys.path.insert(0,str(C))
def dump(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def measure(fn):
    w=time.perf_counter();c=time.process_time();v=fn();return v,dict(wall_seconds=time.perf_counter()-w,cpu_seconds=time.process_time()-c)
def worker(method,trial):
    os.sched_setaffinity(0,{0})
    import numpy as np
    from game2048.runner import create_agent,load_config,play_episode
    from game2048.core import legal_actions
    chosen=json.loads((OUT/'selected.json').read_text(encoding='utf-8'));config=load_config(method)
    if method=='mcts':config['agent'].update(simulations=512,depth=chosen['depth'])
    if method=='td':config['model']='/home/panliang/.cache/game2048-cost-20261110/selected-td-model.npz'
    if method=='expectimax':os.environ['GAME2048_EXPECTIMAX_CACHE']='/home/panliang/.cache/game2048-cost-20261110/exact_fresh_0'
    bank=json.loads((OUT/'shared_board_bank.json').read_text(encoding='utf-8'))['boards']
    def ready():
        a=create_agent(method,config)
        if method=='expectimax':
            from game2048.wrappers.Expectimax.exact import get_solver
            get_solver(256,256.)
        return a
    agent,load=measure(ready)
    for i,b in enumerate(bank[:8]):
        if hasattr(agent,'rng'):agent.rng.seed(7900000+i)
        assert agent.choose(tuple(b)) in legal_actions(tuple(b))
    times=[]
    for i,b in enumerate(bank):
        if hasattr(agent,'rng'):agent.rng.seed(7900000+i)
        t=time.perf_counter_ns();action=agent.choose(tuple(b));us=(time.perf_counter_ns()-t)/1000
        assert action in legal_actions(tuple(b));times.append(dict(board_index=i,action=action,microseconds=us))
    episodes=[]
    for seed in range(6800000,6800003):
        value,cost=measure(lambda:play_episode(agent,seed=seed));episodes.append(dict(**value,**cost))
    r=dict(method=method,trial=trial,phase='online_'+method,affinity=[0],config=config,python=sys.version,
        load_ready=load,shared_board_test=dict(boards=96,rounds=1,calls=96,mean_us=float(np.mean([v['microseconds'] for v in times]))),
        shared_board_rows=times,episodes=episodes,end_to_end=dict(games=3,total_steps=sum(r['steps'] for r in episodes),
            wall_seconds=sum(r['wall_seconds'] for r in episodes),cpu_seconds=sum(r['cpu_seconds'] for r in episodes)),
        peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024)
    dump(OUT/f'cost/{method}_{trial}.json',r);print(json.dumps(dict(method=method,trial=trial,mean_us=r['shared_board_test']['mean_us'])),flush=True)
def main():
    p=argparse.ArgumentParser();p.add_argument('--method');p.add_argument('--trial',type=int,default=0);args=p.parse_args()
    if args.method:worker(args.method,args.trial);return
    assert json.loads((OUT/'status.json').read_text(encoding='utf-8'))['status']=='complete'
    (OUT/'cost').mkdir(exist_ok=True);boards=[];origins=[]
    from game2048.core import legal_actions
    for name in ['完整Expectimax','乐观TD','MCTS']:
        path=OUT/'MCTS_逐步记录.json' if name=='MCTS' else ROOT/f'final_report_20261108/output/原版界面汇报素材/{name}_逐步记录.json'
        records=json.loads(path.read_text(encoding='utf-8'))['records'];candidates=[r['board'] for r in records if len(legal_actions(tuple(r['board'])))>=2]
        for i in range(32):boards.append(candidates[i*(len(candidates)-1)//31]);origins.append(dict(method=name,index=i))
    dump(OUT/'shared_board_bank.json',dict(boards=boards,origins=origins))
    tasks=[];methods=['expectimax','td','mcts']
    for trial in range(3):tasks.extend((m,trial) for m in methods[trial:]+methods[:trial])
    for method,trial in tasks:
        if (OUT/f'cost/{method}_{trial}.json').exists():continue
        subprocess.run([sys.executable,'-u',str(Path(__file__)), '--method',method,'--trial',str(trial)],check=True)
    dump(OUT/'online_cost_results.json',[json.loads((OUT/f'cost/{m}_{t}.json').read_text(encoding='utf-8')) for m,t in tasks])
    dump(OUT/'cost_status.json',dict(status='complete',workers=1,repetitions=3,affinity=[0],boards_per_trial=96,episodes_per_trial=3,
        common_seed_range=[6800000,6800002],note='all depth/confirmation/final tasks completed; original Python MCTS; time medians and process RSS peaks'))
    print('ONLINE_COST_COMPLETE',flush=True)
if __name__=='__main__':main()
