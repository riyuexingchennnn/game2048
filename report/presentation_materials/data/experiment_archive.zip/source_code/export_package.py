"""Audit completed studies, render numerical heatmaps, and publish the compact handoff."""
from pathlib import Path
from collections import Counter
import csv,gzip,hashlib,io,json,math,re,shutil,sys,zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from PIL import Image

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];BASE=ROOT/'final_report_20261108'
TARGET=BASE/'output/大纲与素材';SNAPSHOT=BASE/'.build/网格前交接快照'
STAGE=BASE/'.build/完整调参交接待发布';FIG=STAGE/'图表'
plt.rcParams.update({'font.family':'Microsoft YaHei','font.size':11,'axes.unicode_minus':False,
    'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':180,'axes.titlepad':14})
def read(name):return json.loads((HERE/name).read_text(encoding='utf-8'))
def csvdata(rows):
    out=io.StringIO(newline='');w=csv.DictWriter(out,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    return out.getvalue().encode('utf-8-sig')
def gzrows(path):
    with gzip.open(path,'rt',encoding='utf-8-sig') as f:return list(csv.DictReader(f))
def savefig(fig,name):fig.tight_layout();fig.savefig(FIG/name,bbox_inches='tight');plt.close(fig)
def heat(ax,values,xlabels,ylabels,title,xlabel,ylabel,fmt,limits=None,baseline=None):
    lo,hi=limits if limits else (float(np.min(values)),float(np.max(values)))
    im=ax.imshow(values,origin='lower',aspect='auto',cmap='YlGnBu',vmin=lo,vmax=hi)
    ax.set(xticks=np.arange(len(xlabels)),xticklabels=xlabels,yticks=np.arange(len(ylabels)),yticklabels=ylabels,
        xlabel=xlabel,ylabel=ylabel,title=title)
    ax.set_xticks(np.arange(-.5,len(xlabels),1),minor=True);ax.set_yticks(np.arange(-.5,len(ylabels),1),minor=True)
    ax.grid(which='minor',color='white',linewidth=1.1);ax.tick_params(which='minor',bottom=False,left=False)
    for i in range(values.shape[0]):
        for j in range(values.shape[1]):
            ratio=(values[i,j]-lo)/max(hi-lo,1e-9)
            ax.text(j,i,fmt.format(values[i,j]),ha='center',va='center',fontsize=10,
                color='white' if ratio>.55 else '#18212B',weight='bold' if values[i,j]==values.max() else 'normal')
    if baseline is not None:
        i,j=baseline;ax.add_patch(Rectangle((j-.48,i-.48),.96,.96,fill=False,edgecolor='#D64B36',linewidth=2.5))
    return im

def main():
    for file in ['td_status.json','mcts_status.json','cost_status.json']:assert read(file)['status']=='complete',file
    assert (HERE/'holdout_complete.json').exists()
    if not SNAPSHOT.exists():shutil.copytree(TARGET,SNAPSHOT)
    for name in ['图表','演示','复核数据','模板']:(STAGE/name).mkdir(parents=True,exist_ok=True)
    for name in ['01_TD训练曲线.png','02_万局结果总览.png','03_最大块分布.png']:shutil.copy2(SNAPSHOT/'图表'/name,FIG/name)
    for p in (SNAPSHOT/'演示').glob('*.gif'):shutil.copy2(p,STAGE/'演示'/p.name)
    shutil.copy2(SNAPSHOT/'模板/NKU-beamer-template.zip',STAGE/'模板/NKU-beamer-template.zip')
    audit=[]
    with zipfile.ZipFile(SNAPSHOT/'复核数据/数据与复核.zip') as z:
        oldfiles={name:z.read(name) for name in z.namelist() if name.startswith(('原万局/','原训练/','图表汇总/原万局'))}
    expected={'expectimax':(813.2666,1778,.9954),'td':(640.743,1018,.9119),'mcts':(282.0126,636,.3496)}
    for key,(mean,best,rate) in expected.items():
        rows=list(csv.DictReader(io.StringIO(gzip.decompress(oldfiles[f'原万局/{key}_10000局.csv.gz']).decode())))
        assert {int(r['seed']) for r in rows}==set(range(3000000,3010000)) and len(rows)==10000
        assert abs(np.mean([int(r['sum']) for r in rows])-mean)<1e-10
        assert max(int(r['sum']) for r in rows)==best
        assert abs(np.mean([int(r['max_tile'])>=256 for r in rows])-rate)<1e-12
        expected_counts={'expectimax':{128:46,256:2580,512:7245,1024:129},'td':{32:15,64:92,128:774,256:3621,512:5498},'mcts':{16:1,32:73,64:942,128:5488,256:3494,512:2}}
        assert Counter(int(r['max_tile']) for r in rows)==expected_counts[key]
    audit.append(dict(图表='01—03原模型训练与万局结果',核对='原三万行数据重新核对，沿用已验证图像；不替换为调参数据'))

    mc=read('mcts_grid_results.json');md=read('mcts_design.json');budgets=md['budgets'];depths=md['depths']
    mclook={(r['simulations'],r['depth']):r for r in mc};mcraw=[]
    for b in budgets:
        for d in depths:
            rows=[]
            for offset in range(0,2000,500):rows+=gzrows(HERE/f'mcts/b{b}_d{d}_{offset:04d}.csv.gz')
            assert [int(r['seed']) for r in rows]==list(range(6500000,6502000))
            assert abs(np.mean([int(r['sum']) for r in rows])-mclook[b,d]['mean_sum'])<1e-10
            assert abs(np.mean([int(r['max_tile'])>=256 for r in rows])-mclook[b,d]['success_256'])<1e-12
            mcraw.extend(dict(simulations=b,depth=d,**r) for r in rows)
    for metric,name,title,fmt,limits in [('mean_sum','04_MCTS平均总和热力图.png','MCTS：平均终局总和','{:.1f}',None),
        ('success_256','05_MCTS成功率热力图.png','MCTS：256达标率（%）','{:.1f}%',(0,100))]:
        values=np.array([[mclook[b,d][metric] for b in budgets] for d in depths])*(100 if metric=='success_256' else 1)
        fig,ax=plt.subplots(figsize=(9.2,6.2));im=heat(ax,values,budgets,depths,title,'每步模拟次数','搜索深度',fmt,limits,(depths.index(12),budgets.index(128)))
        fig.colorbar(im,ax=ax,fraction=.045,pad=.04);savefig(fig,name)
    audit.append(dict(图表='04—05 MCTS热力图',核对='36格×2000局=72000行逐项重算；成功率分母固定2000'))

    td=read('td_grid_results.json');design=read('td_design.json');configs=design['configurations'];seeds=design['training_seeds']
    assert sum(read(f'td_seed_{seed}/completion.json')['executed_training_batches'] for seed in seeds)*10000==design['executed_training_games_if_no_resume']
    lookup={(r['config']['id'],r['train_seed']):r for r in td};summaries=[];tdraw=[];logs=[]
    assert len(lookup)==175
    for config in configs:
        cid=config['id'];means=[];rates=[]
        for seed in seeds:
            row=lookup[cid,seed];raw=gzrows(HERE/f'td_seed_{seed}/{cid}_test.csv.gz')
            assert [int(r['seed']) for r in raw]==list(range(6600000,6602000)) and all(float(r['truncated'])==0 for r in raw)
            m=float(np.mean([int(r['sum']) for r in raw]));p=float(np.mean([int(r['max_tile'])>=256 for r in raw]))
            assert abs(m-row['mean_sum'])<1e-10 and abs(p-row['success_256'])<1e-12
            means.append(m);rates.append(p);tdraw.extend(dict(config=cid,train_seed=seed,**r) for r in raw)
            logs.extend(dict(config=cid,train_seed=seed,**r) for r in row['train_log'])
        summaries.append(dict(id=cid,kind=config['kind'],alpha_end=config['alpha_end'],epsilon_end=config['epsilon_end'],
            alpha_switch=config['alpha_switch'],epsilon_switch=config['epsilon_switch'],shape=config['shape'],
            mean_sum=float(np.mean(means)),sum_seed_sd=float(np.std(means,ddof=1)),success_256=float(np.mean(rates)),success_seed_sd=float(np.std(rates,ddof=1))))
    assert lookup['grid_a1_e1',42]['reproduces_original_weights']
    sl={r['id']:r for r in summaries};alphas=[.01,.03,.05,.1,.2];eps=[0,.002,.005,.01,.02]
    fig,axes=plt.subplots(1,2,figsize=(13.2,5.5))
    for ax,metric,title,fmt,scale in [(axes[0],'mean_sum','TD：平均终局总和','{:.1f}',1),(axes[1],'success_256','TD：256达标率（%）','{:.2f}%',100)]:
        values=np.array([[sl[f'grid_a{a}_e{e}'][metric] for e in range(5)] for a in range(5)])*scale
        im=heat(ax,values,['0','0.002','0.005','0.010','0.020'],['0.01','0.03','0.05','0.10','0.20'],title,'24万局后的探索率ε','21万局后的学习率α',fmt,baseline=(1,1))
        fig.colorbar(im,ax=ax,fraction=.04,pad=.025)
    savefig(fig,'06_TD参数数值热力图.png')
    timing={(r['alpha_switch'],r['epsilon_switch']):r for r in summaries if r['kind']=='timing'};timing[210000,240000]=sl['grid_a1_e1']
    aa=[150000,210000,270000];ee=[180000,240000,270000]
    fig,axes=plt.subplots(1,2,figsize=(11.8,4.8))
    for ax,metric,title,fmt,scale in [(axes[0],'mean_sum','TD：平均终局总和','{:.1f}',1),(axes[1],'success_256','TD：256达标率（%）','{:.2f}%',100)]:
        values=np.array([[timing[a,e][metric] for e in ee] for a in aa])*scale
        im=heat(ax,values,[18,24,27],[15,21,27],title,'探索率切换局数（万）','学习率切换局数（万）',fmt,baseline=(1,1));fig.colorbar(im,ax=ax,fraction=.04,pad=.03)
    savefig(fig,'07_TD切换时机热力图.png')
    shapes=['grid_a1_e1','linear','cosine'];labels=['分段跳变','线性渐变','余弦渐变'];colors=['#306F9E','#E7A23B','#399477']
    cl={c['id']:c for c in configs};fig,axes=plt.subplots(2,2,figsize=(11.8,8.5))
    for i,(cid,label,color) in enumerate(zip(shapes,labels,colors)):
        sched=np.array(cl[cid]['schedule']);xx=np.arange(0,300000,10000)/10000
        for ax,k in [(axes[0,0],0),(axes[0,1],1)]:ax.step(np.r_[xx,30],np.r_[sched[:,k],sched[-1,k]],where='post',label=label,color=color,lw=2)
    axes[0,0].set(title='实际学习率日程',xlabel='已完成训练局数（万）',ylabel='学习率α')
    axes[0,1].set(title='实际探索率日程',xlabel='已完成训练局数（万）',ylabel='探索率ε');axes[0,1].legend(frameon=False)
    for ax,metric,sd,title,scale in [(axes[1,0],'mean_sum','sum_seed_sd','冻结测试平均终局总和',1),(axes[1,1],'success_256','success_seed_sd','冻结测试256达标率（%）',100)]:
        vals=np.array([sl[c][metric] for c in shapes])*scale;err=np.array([sl[c][sd] for c in shapes])*scale
        ax.bar(np.arange(3),vals,yerr=err,capsize=4,color=colors,width=.6);ax.set_xticks(np.arange(3),labels);ax.set_title(title)
        ax.set_ylim(0,110 if scale==100 else max(vals+err)*1.15)
        for i,v in enumerate(vals):ax.text(i,v+err[i]+(.8 if scale==100 else 5),f'{v:.2f}%' if scale==100 else f'{v:.1f}',ha='center')
    for ax in axes.flat:ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
    savefig(fig,'08_TD参数日程与结果.png')
    audit.append(dict(图表='06—08 TD调参',核对='175模型×2000局=350000行逐项重算；每格5训练种子均值；日程按实际30批参数绘制；误差条为样本标准差'))

    # Fresh holdout is kept distinct from the grid used for selection.
    mh=read('mcts_holdout_results.json');th=read('td_holdout_results.json');holdrows=[];mchraw=[];tdhraw=[]
    baseline_mc=next(r for r in mh if (r['simulations'],r['depth'])==(128,12))
    for row in mh:
        raw=gzrows(HERE/f'holdout/mcts_b{row["simulations"]}_d{row["depth"]}.csv.gz')
        assert [int(r['seed']) for r in raw]==list(range(6750000,6753000))
        assert abs(np.mean([int(r['sum']) for r in raw])-row['mean_sum'])<1e-10
        assert abs(np.mean([int(r['max_tile'])>=256 for r in raw])-row['success_256'])<1e-12
        mchraw.extend(dict(simulations=row['simulations'],depth=row['depth'],**r) for r in raw)
        holdrows.append(dict(method='MCTS',config=f'B={row["simulations"]},h={row["depth"]}',models=1,games_per_model=3000,mean_sum=row['mean_sum'],success_256=row['success_256'],sum_seed_sd='',paired_sum_delta='',paired_ci_low='',paired_ci_high=''))
    thids=sorted({r['config'] for r in th});thlookup={(r['config'],r['train_seed']):r for r in th};base=np.array([thlookup['grid_a1_e1',s]['mean_sum'] for s in seeds])
    for cid in thids:
        vals=np.array([thlookup[cid,s]['mean_sum'] for s in seeds]);rr=np.array([thlookup[cid,s]['success_256'] for s in seeds])
        delta=vals-base;margin=2.776445105*delta.std(ddof=1)/np.sqrt(5)
        holdrows.append(dict(method='TD',config=cid,models=5,games_per_model=5000,mean_sum=float(vals.mean()),success_256=float(rr.mean()),sum_seed_sd=float(vals.std(ddof=1)),paired_sum_delta=float(delta.mean()),paired_ci_low=float(delta.mean()-margin),paired_ci_high=float(delta.mean()+margin)))
        for seed in seeds:
            raw=gzrows(HERE/f'holdout/td_{cid}_{seed}.csv.gz')
            assert [int(r['seed']) for r in raw]==list(range(6700000,6705000)) and all(float(r['truncated'])==0 for r in raw)
            assert abs(np.mean([int(r['sum']) for r in raw])-thlookup[cid,seed]['mean_sum'])<1e-10
            assert abs(np.mean([int(r['max_tile'])>=256 for r in raw])-thlookup[cid,seed]['success_256'])<1e-12
            tdhraw.extend(dict(config=cid,train_seed=seed,**r) for r in raw)

    cost=read('cost_all_results.json');costlook={(r['phase'],r['trial']):r for r in cost};costrows=[];costdetail=[];latencies=[];episodes=[]
    for method in ['expectimax','td','mcts']:
        online=[costlook['online_'+method,i] for i in range(3)]
        if method=='expectimax':
            off=[costlook['compile_exact',i]['compile']['wall_seconds']+costlook['exact_prepare',i]['prepare']['wall_seconds'] for i in range(3)]
            offpeak=max(costlook['exact_prepare',i]['peak_rss_bytes'] for i in range(3));disk=costlook['exact_prepare',0]['persistent_cache_bytes']
        elif method=='td':
            off=[sum(costlook['td_train',i][key]['wall_seconds'] for key in ['jit_first_call','train','save']) for i in range(3)]
            offpeak=max(costlook['td_train',i]['peak_rss_bytes'] for i in range(3));disk=(COST_MODEL:=ROOT/'final_report_20261108/.build/report-pr-20261108/checkout/models/TD/optimistic-5tuple-300k.npz').stat().st_size
        else:off=[0.,0.,0.];offpeak=0;disk=0
        choose=[r['shared_board_test']['mean_us'] for r in online];loads=[r['load_ready']['wall_seconds'] for r in online]
        cpu_ms=[r['end_to_end']['cpu_seconds']/r['end_to_end']['total_steps']*1000 for r in online]
        row=dict(method=method,offline_median_s=float(np.median(off)),offline_min_s=min(off),offline_max_s=max(off),
            ready_load_median_s=float(np.median(loads)),choose_mean_us_median=float(np.median(choose)),choose_mean_us_min=min(choose),choose_mean_us_max=max(choose),
            online_peak_rss_MiB=max(r['peak_rss_bytes'] for r in online)/2**20,offline_peak_rss_MiB=offpeak/2**20,
            persistent_artifact_MiB=disk/2**20,end_to_end_cpu_ms_per_step_median=float(np.median(cpu_ms)),
            mean_episode_wall_s_median=float(np.median([r['end_to_end']['wall_seconds']/10 for r in online])))
        costrows.append(row)
        for i,r in enumerate(online):
            assert r['affinity']==[0] and r['shared_board_test']['calls']==288 and len(r['episodes'])==10
            latencies.extend(dict(method=method,trial=i,**v) for v in r['shared_board_rows']);episodes.extend(dict(method=method,trial=i,**v) for v in r['episodes'])
            if i:assert [(v['seed'],v['sum'],v['steps']) for v in r['episodes']]==[(v['seed'],v['sum'],v['steps']) for v in online[0]['episodes']]
        for i in range(3):
            if method=='expectimax':
                costdetail.extend(dict(method=method,trial=i,phase=phase,**costlook[phase,i][key]) for phase,key in [('compile_exact','compile'),('exact_prepare','prepare')])
            elif method=='td':costdetail.extend(dict(method=method,trial=i,phase=key,**costlook['td_train',i][key]) for key in ['jit_first_call','train','save'])
            costdetail.append(dict(method=method,trial=i,phase='load_ready',**online[i]['load_ready']))
    fig,axes=plt.subplots(1,3,figsize=(14,4.8));names=['完整Expectimax','乐观TD','MCTS'];cc=['#306F9E','#7E0C6E','#748694']
    for ax,key,title,logscale in [(axes[0],'offline_median_s','首次训练／建表与保存（秒）',False),(axes[1],'choose_mean_us_median','共同棋盘平均决策耗时（微秒）',True),(axes[2],'online_peak_rss_MiB','推理进程峰值RSS（MiB）',False)]:
        vals=[r[key] for r in costrows];ax.bar(np.arange(3),vals,color=cc,width=.6);ax.set_xticks(np.arange(3),names);ax.set_title(title)
        if logscale:ax.set_yscale('log');ax.set_ylim(min(vals)*.35,max(vals)*3.5)
        else:ax.set_ylim(0,max(vals)*1.22)
        for i,v in enumerate(vals):ax.text(i,v*1.2 if logscale else v+max(vals)*.035,f'{v:.2f}' if key!='online_peak_rss_MiB' else f'{v:.1f}',ha='center')
        ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
    savefig(fig,'09_统一成本对比.png')
    audit.append(dict(图表='09统一成本',核对='同WSL环境、单逻辑CPU、单线程，独立串行3次；准备含编译/JIT与保存；决策使用共同96棋盘；峰值RSS来自OS记录'))

    # Replace old one-dimensional tuning/cost sections without multiplying documents.
    guide=(SNAPSHOT/'大纲.md').read_text(encoding='utf-8')
    a=guide.index('## 文件怎么用');b=guide.index('## 展示安排')
    guide=guide[:a]+'''## 文件怎么用与图表核对

主目录共15个文件：9张PNG、3个原版游戏GIF、一份大纲、一份模板、一份复核附件。每张图片仅一份，不放SVG或重复截图。

| 用途 | 文件 |
| --- | --- |
| 主展示 | 01原模型训练曲线、02原万局结果、03最大块分布；三种方法的GIF |
| 调参 | 04 MCTS平均总和热力图、05 MCTS成功率热力图；06 TD参数数值、07切换时机、08渐变日程 |
| 成本与问答 | 09统一成本图，以及本文完整成本表 |
| 复核 | [数据与复核](复核数据/数据与复核.zip)，含逐局数据、实际参数日程、统计、代码和计时边界 |

5分钟内不需要展示全部9张图：MCTS方法页优先使用04／05中的一张，TD方法页优先使用06；07／08和完整成本表作为问答材料。算法公式与实现细节保留，供报告制作取舍。

原万局主榜不变。新增网格用验证集选候选，再用独立保留集复测；三种数据分别说明。MCTS使用原Gym规则，网格计算采用经动作与随机数状态核对的C++加速器；TD调参采用规则等价的Numba仿真器。二者的网格分数不直接作跨方法新排名。

01—03已核对原三万条测试数据及训练记录；04—05从72,000条网格记录逐格重算；06—08从175个模型、350,000条冻结验证记录重算。热力图加粗格为该图点估计最大值，红框标记原配置，不能据此认为相邻格差异已显著。TD日程结果柱图误差条为五个训练种子间样本标准差。09来自同环境、无实验任务并发的串行成本测量。数值与记录的一致性已经检查，有限样本结论按下面的统计范围解释。

''' +guide[b:]
    a=guide.index('### 新增本地对照：模拟次数与深度');b=guide.index('## 方法三',a)
    mcbestmean=max(mc,key=lambda r:r['mean_sum']);mcbestrate=max(mc,key=lambda r:r['success_256'])
    mctext=f'''### 二维网格：模拟预算×搜索深度

采用6×6网格，共36组。模拟次数B取16、32、64、128、256、512；深度h取3、6、9、12、18、24。每格使用相同2,000个验证种子6,500,000—6,501,999，达到256后继续至自然终局，其余参数固定。6×6覆盖了成倍增长的预算和从浅到深的范围，避免把固定实验预算摊到过多格子而减少每格样本量。

图：[平均终局总和热力图](图表/04_MCTS平均总和热力图.png)、[256达标率热力图](图表/05_MCTS成功率热力图.png)。格子直接标注实际数值。验证集最高平均总和为B={mcbestmean['simulations']}、h={mcbestmean['depth']}的{mcbestmean['mean_sum']:.3f}；最高达标率为B={mcbestrate['simulations']}、h={mcbestrate['depth']}的{mcbestrate['success_256']:.2%}。两个目标偏好的参数可能不同。

每格2,000局只是有限样本，相邻格很小的数值差不代表可靠排序。按两个指标各取验证集前三名，并加入原128／12配置，合并去重后预先固定候选，用新种子6,750,000—6,752,999各复测3,000局。

| B | h | 独立保留集平均总和 | ≥256 |
| ---: | ---: | ---: | ---: |
'''
    for r in sorted(mh,key=lambda r:r['mean_sum'],reverse=True):mctext+=f"| {r['simulations']} | {r['depth']} | {r['mean_sum']:.3f} | {r['success_256']:.2%} |\n"
    mctext+='\n完整原始记录在复核附件。网格图只展示固定预算下的敏感性，不宣称有限网格找到了全局最优。原万局主榜继续使用128／12配置。\n\n'
    guide=guide[:a]+mctext+guide[b:]
    a=guide.index('#### 控制变量：');b=guide.index('## 训练曲线',a)
    tdtext='''#### 35组配置、5个训练种子的对照

每模型训练30万局，初始化总价值300、对称5-tuple、γ=1、λ=0均固定。种子为42、137、2026、31415、271828。各配置相同参数的训练前缀只计算一次，再复制分支；每模型逻辑训练预算相同，后续批次随机种子均为“训练种子＋批首局数”。合计175模型、5,250万逻辑训练局，实际执行1,325万局，节省重复前缀。

**数值网格25组：**前21万局α=0.1，之后α取0.01、0.03、0.05、0.10、0.20；前24万局ε=0.02，之后ε取0、0.002、0.005、0.010、0.020。包含降低、保持以及学习率提高的对照，不把全部组统称为“衰减”。每个模型冻结权重、ε=0，在相同验证种子6,600,000—6,601,999上测试2,000局。图：[TD参数数值](图表/06_TD参数数值热力图.png)。每格是五个训练模型的测试均值，不把10,000条游戏样本当作10,000次独立训练。

**切换时机9组：**终值固定α=0.03、ε=0.002；α切换点取15／21／27万局，ε切换点取18／24／27万局，组成3×3网格。其中原21／24万局配置与25组数值网格重合，所以新增8组。图：[TD切换时机](图表/07_TD切换时机热力图.png)。

**渐变日程2组：**与原分段跳变比较线性、余弦两种形状。α从21万局起由0.1渐变到0.03，ε从24万局起由0.02渐变到0.002，最后一个批次开始时达到终值；每批10,000局内参数固定。实际30批参数数值保存在附件，图：[TD参数日程与结果](图表/08_TD参数日程与结果.png)。渐变与跳变的累计探索量不同，本实验比较整套日程，不能把差异只归因于平滑性。

原21／24万局、0.03／0.002配置的种子42权重逐项复现保留模型。验证集只用于筛选：按平均总和与达标率各取前两名，加入原配置，去重后冻结候选，再用独立种子6,700,000—6,704,999，每模型5,000局复测。没有看到保留集后再训练或改参数。

| 候选配置 | 独立保留集平均总和 | ≥256 | 相对原配置平均总和差（95%配对t区间） |
| --- | ---: | ---: | --- |
'''
    def configlabel(cid):
        c=cl[cid]
        if c['kind']=='values':return f"α={c['alpha_end']:g}，ε={c['epsilon_end']:g}；切换21／24万"
        if c['kind']=='timing':return f"α→0.03@{c['alpha_switch']//10000}万，ε→0.002@{c['epsilon_switch']//10000}万"
        return {'linear':'线性渐变','cosine':'余弦渐变'}[cid]
    for r in sorted([r for r in holdrows if r['method']=='TD'],key=lambda r:r['mean_sum'],reverse=True):
        tdtext+=f"| {configlabel(r['config'])} | {r['mean_sum']:.3f} | {r['success_256']:.2%} | {r['paired_sum_delta']:+.3f}［{r['paired_ci_low']:.3f}，{r['paired_ci_high']:.3f}］ |\n"
    tdtext+='\n区间按五个训练种子的模型均值配对，自由度4，描述固定保留集下的训练种子波动，未作多重比较校正。应结合均值、达标率、种子间波动与区间判断；不能只挑一个最高数字宣称普遍最优。所有验证与保留集测试均冻结权重、使用ε=0，避免把少走随机动作直接当成学习能力提高。\n\n'
    tdtext+='**这轮对调参理由的修正：**降低学习率可以减小更新幅度，但不等于越早降越好；本轮较好的组合让α=0.1保留到27万局，同时在18万局把ε降到0.002。解释上，它保留了后期较快的价值修正，并更早集中到当前策略常访问的状态；这是对观察结果的解释，尚未把状态覆盖和更新噪声分别测量。线性与余弦日程的验证均值均略高于原跳变日程，但没有超过较好的切换时机配置；两种渐变方案未进入独立保留集复测，不能把这点小幅提高当成确定优势。\n\n'
    tdtext+='数值网格中可以作以下固定其余参数的直观比较（均为验证集五模型均值）：\n\n| 比较条件 | 终值 | 平均总和 | ≥256 |\n| --- | --- | ---: | ---: |\n'
    for cid,label in [('grid_a0_e1','固定ε=0.002，改变α'),('grid_a1_e1','固定ε=0.002，改变α'),('grid_a4_e1','固定ε=0.002，改变α'),('grid_a1_e0','固定α=0.03，改变ε'),('grid_a1_e4','固定α=0.03，改变ε')]:
        r=sl[cid];tdtext+=f"| {label} | α={r['alpha_end']:g}，ε={r['epsilon_end']:g} | {r['mean_sum']:.3f} | {r['success_256']:.2%} |\n"
    tdtext+='\n较大的α=0.20在这组末段训练设置中表现更差；ε=0、0.002和0.02的测试结果来自不同训练轨迹，最终测试时都使用ε=0。上述数字说明具体设置下的差别，不证明任意任务都应采用同样的终值。\n\n'
    guide=guide[:a]+tdtext+guide[b:]
    a=guide.index('## 成本附表');b=guide.index('## 实验报告安排',a)
    costtext='''## 统一成本对比：替换原历史计时

之前42.25秒建表、64.30秒训练来自不同环境和计时边界，不能直接比较，本节以重新实测为准。

本轮同一台i9-10900K、WSL Ubuntu、Python环境，单进程、单线程，固定到逻辑CPU0；调参和保留集任务全部结束后，使用全新子进程串行测量，独立重复3次。依赖已安装，公共环境模块先导入；加载阶段包含智能体模块首次导入、构造和产物加载，首次训练／建表计时则在所需模块导入后开始。未强行清空操作系统页缓存。

主表采用仓库实际实现：Expectimax为C++求解器，MCTS为原Python实现，TD为NumPy查表。网格用的MCTS C++加速器不冒充原Python版的运行成本。

| 方法 | 首次产物准备／秒 | 已有产物加载／秒 | 共同棋盘平均决策／微秒 | 推理峰值RSS／MiB | 持久文件／MiB |
| --- | ---: | ---: | ---: | ---: | ---: |
'''
    cname={'expectimax':'完整Expectimax','td':'乐观TD','mcts':'MCTS'}
    for r in costrows:costtext+=f"| {cname[r['method']]} | {r['offline_median_s']:.3f} | {r['ready_load_median_s']:.4f} | {r['choose_mean_us_median']:.2f} | {r['online_peak_rss_MiB']:.1f} | {r['persistent_artifact_MiB']:.3f} |\n"
    costtext+='''
图：[统一成本对比](图表/09_统一成本对比.png)。决策耗时坐标使用对数刻度，避免量级差异掩盖较快方法。首次产物准备包含：Expectimax的C++编译、空缓存下完整建表及保存；TD的冷JIT首次调用、权重分配、30万局训练及保存。MCTS没有离线训练或持久价值表，该项为0；其构造开销计入加载列。

加载列是在产物已经存在时，创建智能体并加载权重／完整价值缓存，包含Expectimax真正完成缓存准备，不把它延迟到第一次决策。主表前三个时间列取三次实验的中位数；决策列先计算每次实验的平均耗时，再取三次中位数。RSS为三次新进程中观察到的最大峰值，包含Python、依赖和模型，不用参数数组大小替代进程内存。持久文件是实际模型压缩文件或价值缓存的磁盘大小。

共同棋盘来自原三个演示轨迹，各均匀取32个至少有两个合法动作的棋盘，共96个，三种方法使用完全相同输入；每次实验循环3遍，共288次选择。该棋盘集覆盖三条实际轨迹，不代表全部可达状态的均匀分布。另用相同10个新种子完成整局测试，重复3次，统计环境与决策一起的耗时：

| 方法 | 每局平均墙钟／秒（三次中位数） | 每实际步CPU耗时／毫秒（三次中位数） | 首次准备阶段峰值RSS／MiB |
| --- | ---: | ---: | ---: |
'''
    for r in costrows:costtext+=f"| {cname[r['method']]} | {r['mean_episode_wall_s_median']:.4f} | {r['end_to_end_cpu_ms_per_step_median']:.4f} | {r['offline_peak_rss_MiB']:.1f} |\n"
    costtext+='\n各方法游戏局长不同，整局耗时不能单独说明每步效率；共同棋盘的决策耗时用于补充这一点。所有阶段的墙钟秒、当前进程CPU秒、三次原始值、逐次决策耗时和真实对局步数都在附件中；编译阶段的当前进程CPU秒不包含外部编译器子进程，因此编译成本以墙钟秒为准。计时仍会受到系统后台活动影响，因此保留重复范围，不宣称硬实时上界。训练／建表计算量与方法性质不同，此表是当前实现的实际使用成本，不是同训练预算下的公平性能排名。\n\n'
    guide=guide[:a]+costtext+guide[b:]
    # Drop stale previous experiment accounting and file lists.
    a=guide.index('## 调参复核与数据使用');b=guide.index('## 参考文献与引用边界',a)
    guide=guide[:a]+'''## 复核数据与实验调度

[数据与复核.zip](复核数据/数据与复核.zip)包含原三万局与训练记录、72,000局MCTS网格、175模型的350,000局TD验证、候选独立保留集、35种配置的逐批日程、训练日志、统一成本的全部阶段记录，以及运行／绘图代码。大模型权重与1GiB价值缓存不放入素材包，正式模型仍使用原项目仓库版本。

本机10核20线程。MCTS网格使用8个单线程进程，以500局为小任务块、优先调度较重配置，支持完成块复用；TD使用5个训练种子进程，按相同参数日程前缀共享权重分支，避免重复训练。MCTS网格完成后释放的资源用于候选保留集；所有并行任务结束后再做单核成本测试，避免把并发争抢误当成算法速度。

热力图数值、样本数、种子范围、模型冻结与训练前缀复用规则均由记录校验；完整权重保留在本地实验目录，不直接替换正式模型。运行代码保留本地项目路径，复跑前需要核对目录和依赖；MCTS及完整求解使用WSL和C++，TD训练使用Numba。

''' +guide[b:]
    guide=guide.replace('图表/04_MCTS调参.png','图表/04_MCTS平均总和热力图.png').replace('图表/05_TD调参.png','图表/06_TD参数数值热力图.png')
    guide=guide.replace('四组调参表','参数网格').replace('四组日程对照及核心结论；固定权重对照用于问答','参数终值与切换时机的主要结论，详细网格留问答')
    guide=guide.replace('冻结检查点评测保留在复核附件；不放累计测试曲线冒充训练过程。','不放累计测试曲线冒充训练过程。')
    guide=guide.replace('成本表用于PPT附页','成本表与统一实测图用于PPT附页')
    guide=guide.replace('不编造工时或工作量百分比。参考文献见文末。','')
    guide=guide.replace('21万／24万切换点、0.03／0.002幅度均是已有日程，本次验证“是否下降”的作用，没有扫描最优切换点或最优数值。','21万／24万切换点、0.03／0.002幅度是原选定模型的日程；本轮在下节分别扫描终值、切换时机和渐变形状。')
    guide=guide.replace('历史首次准备约42.25秒，记录玩家状态48,713,519、随机状态31,431,374，持久缓存约1GiB；这些是准备成本，不是策略训练局数。','本轮三次完整建表均记录玩家状态48,713,519、随机状态31,431,374，持久价值缓存1GiB；首次准备耗时见统一成本表，这些是求解准备，不是策略训练局数。')
    guide=guide.replace('成本表、TD特征更新公式、置信区间和固定权重实验放备份页。','成本表、TD特征更新公式、置信区间和完整调参网格放备份页。')
    (STAGE/'大纲.md').write_text(guide,encoding='utf-8')
    schedules=[dict(config=c['id'],batch_start=i*10000,batch_end=(i+1)*10000,alpha=pair[0],epsilon=pair[1]) for c in configs for i,pair in enumerate(c['schedule'])]
    with zipfile.ZipFile(STAGE/'复核数据/数据与复核.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,data in oldfiles.items():z.writestr(name,data)
        for name,rows in [('MCTS网格逐局',mcraw),('TD网格逐局',tdraw),('MCTS独立保留集逐局',mchraw),('TD独立保留集逐局',tdhraw)]:z.writestr('逐局数据/'+name+'.csv.gz',gzip.compress(csvdata(rows),mtime=0))
        for name,rows in [('MCTS网格汇总',mc),('TD配置汇总',summaries),('TD逐批参数日程',schedules),('TD训练日志',logs),('独立保留集汇总',holdrows),('成本主表',costrows),('成本阶段计时',costdetail),('共同棋盘逐次延迟',latencies),('真实整局成本',episodes),('图表核对',audit)]:z.writestr('汇总/'+name+'.csv',csvdata(rows))
        for name in ['mcts_design.json','td_design.json','holdout_design.json','shared_board_bank.json','cost_design.json','cost_all_results.json','mcts_status.json','td_status.json','cost_status.json']:z.write(HERE/name,'设计与核对/'+name)
        for name in ['engine_reference.py','mcts_grid.py','td_grid.py','holdout.py','cost_benchmark.py','pipeline.py','early_mcts_holdout.py','export_package.py']:z.write(HERE/name,'运行代码/'+name)
        checkout=ROOT/'final_report_20261108/.build/report-pr-20261108/checkout'
        dependencies=[ROOT/'本地实验/调参对照_20261110/run_mcts_parameters.py',checkout/'report/benchmark10000/run.py',checkout/'report/benchmark10000/native_mcts.cpp']
        dependencies+=sorted(p for p in (checkout/'game2048').rglob('*') if p.is_file() and p.suffix in ['.py','.cpp','.json'] and 'ppo' not in p.parts)
        dependencies+=[checkout/f'config/{method}.yaml' for method in ['expectimax','mcts','td']]
        for p in dependencies:z.write(p,'实现依据/'+p.relative_to(ROOT).as_posix())
        z.writestr('运行代码/复跑说明.txt','这里保留的是实际运行脚本和所依赖的算法源码，方便审核。脚本使用原本的本地目录结构，复跑前需把路径指向项目，并安装NumPy、Numba、Matplotlib、Gymnasium、Pygame；MCTS与Expectimax部分需要WSL及C++17编译器。原选定TD权重及三条演示逐步记录沿用项目已有文件，未在素材附件中重复存放。实现依据目录保留相对工作区的原路径，可据此恢复依赖位置。成本程序仅在网格和独立保留集结束后运行；若重测首次准备，应改用新的WORK目录，避免命中已有产物。不要直接覆盖已有实验记录。'.encode('utf-8'))
    for link in re.findall(r'\]\(([^)]+)\)',guide):
        if not link.startswith('https://'):assert (STAGE/link).is_file(),link
    files=sorted(p for p in STAGE.rglob('*') if p.is_file())
    assert len(files)==15 and sum(p.suffix=='.png' for p in files)==9 and sum(p.suffix=='.gif' for p in files)==3
    assert not any(p.suffix=='.svg' for p in files)
    for p in files:
        if p.suffix=='.png':
            with Image.open(p) as im:im.verify()
        if p.suffix=='.zip':
            with zipfile.ZipFile(p) as z:assert z.testzip() is None
    if '--preview' in sys.argv:
        print(json.dumps(dict(preview=str(STAGE),files=len(files),cost=costrows,holdout=holdrows),ensure_ascii=True))
        return
    archive=BASE/'output/大纲与素材.zip';temporary=archive.with_suffix('.tmp.zip')
    with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files:z.write(p,Path('大纲与素材')/p.relative_to(STAGE))
    with zipfile.ZipFile(temporary) as z:
        assert z.testzip() is None and len(z.infolist())==15
        for p in files:assert hashlib.sha256(z.read((Path('大纲与素材')/p.relative_to(STAGE)).as_posix())).digest()==hashlib.sha256(p.read_bytes()).digest()
    # Verify both absolute directory targets before the reversible directory move.
    assert TARGET.resolve()==(BASE/'output/大纲与素材').resolve() and TARGET.resolve().is_relative_to(ROOT.resolve())
    assert STAGE.resolve().is_relative_to((BASE/'.build').resolve())
    backup=BASE/'.build/网格发布前素材';assert not backup.exists()
    if TARGET.exists():shutil.move(str(TARGET),str(backup))
    shutil.move(str(STAGE),str(TARGET));temporary.replace(archive)
    result=dict(archive=str(archive),files=15,png=9,mcts_validation_games=len(mcraw),td_validation_games=len(tdraw),
        mcts_holdout_games=len(mchraw),td_holdout_games=len(tdhraw),cost=costrows,td_summary=summaries,holdout=holdrows)
    (HERE/'export_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(archive=str(archive),files=15,bytes=archive.stat().st_size),ensure_ascii=True))

if __name__=='__main__':main()
