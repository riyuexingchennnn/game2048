"""Serial, pinned-core cost benchmark; never run concurrently with the parameter grids."""
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS']:os.environ[key]='1'
os.environ['PYGAME_HIDE_SUPPORT_PROMPT']='1'
from pathlib import Path
import argparse,csv,hashlib,json,platform,resource,shutil,statistics,subprocess,sys,time

OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1]
C=ROOT/'final_report_20261108/.build/report-pr-20261108/checkout'
WORK=Path('/home/panliang/.cache/game2048-cost-20261110')
sys.path.insert(0,str(C))

def dump(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');temp.replace(path)
def measure(function):
    wall=time.perf_counter();cpu=time.process_time();value=function()
    return value,dict(wall_seconds=time.perf_counter()-wall,cpu_seconds=time.process_time()-cpu)
def rss():return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024

def worker(phase,trial):
    os.sched_setaffinity(0,{0});WORK.mkdir(exist_ok=True,parents=True)
    result=dict(phase=phase,trial=trial,affinity=list(os.sched_getaffinity(0)),python=sys.version,platform=platform.platform())
    if phase=='compile_exact':
        dest=WORK/f'library_{trial}';dest.mkdir(exist_ok=True);os.environ['GAME2048_EXPECTIMAX_CACHE']=str(dest)
        from game2048.wrappers.Expectimax.exact import _library
        _,result['compile']=measure(_library)
        result['library']=str(next(dest.glob('solver-*.so')))
        result['child_peak_rss_bytes']=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss*1024
    elif phase=='exact_prepare':
        dest=WORK/f'exact_fresh_{trial}';dest.mkdir(exist_ok=True)
        assert not list(dest.glob('sum-*.bin')),'fresh-preparation trial already has a value cache'
        for lib in (WORK/f'library_{trial}').glob('solver-*.so'):shutil.copy2(lib,dest/lib.name)
        os.environ['GAME2048_EXPECTIMAX_CACHE']=str(dest)
        from game2048.wrappers.Expectimax.exact import get_solver,_library
        _library();result['rss_before_bytes']=rss()
        solver,result['prepare']=measure(lambda:get_solver(256,256.))
        result['persistent_cache_bytes']=sum(p.stat().st_size for p in dest.glob('sum-*.bin'))
        result['cache_file']=str(next(dest.glob('sum-*.bin')))
    elif phase=='td_train':
        import numpy as np
        # A fresh JIT directory separates compilation from the timed training loop.
        os.environ['NUMBA_CACHE_DIR']=str(WORK/f'jit_{trial}')
        sys.path.insert(0,str(WORK/'training_source'))
        import engine_reference as E
        p,t=E.patterns(5,True);w=np.full((3,16**5),12.5,dtype=np.float32)
        _,result['jit_first_call']=measure(lambda:E.train_batch(w,p,t,1,42,.1,.02,0,0.))
        seed=[42,137,2026][trial];result['training_seed']=seed
        def train():
            weights=np.full((3,16**5),12.5,dtype=np.float32);steps=0
            for start in range(0,300000,10000):
                batch=E.train_batch(weights,p,t,10000,seed+start,.1 if start<210000 else .03,.02 if start<240000 else .002,0,0.)
                # Same batch statistics as the historical training boundary.
                float(batch[:,0].mean());float(np.mean(batch[:,1]>=256));steps+=int(batch[:,2].sum())
            return weights,steps
        result['rss_before_bytes']=rss();(weights,steps),result['train']=measure(train)
        result['training_games']=300000;result['training_steps']=steps;result['weights_array_bytes']=weights.nbytes
        if trial==0:
            with np.load(C/'models/TD/optimistic-5tuple-300k.npz') as original:assert np.array_equal(weights,original['weights'])
            result['reproduces_selected_weights']=True
        path=WORK/f'td_trial_{trial}.npz'
        _,result['save']=measure(lambda:np.savez_compressed(path,weights=weights,positions=p,tables=t))
        result['model_file_bytes']=path.stat().st_size
    elif phase.startswith('online_'):
        import numpy as np
        from game2048.runner import create_agent,load_config,play_episode
        from game2048.core import legal_actions
        method=phase.removeprefix('online_');result['method']=method
        if method=='expectimax':os.environ['GAME2048_EXPECTIMAX_CACHE']=str(WORK/'exact_fresh_0')
        bank=json.loads((OUT/'shared_board_bank.json').read_text(encoding='utf-8'))['boards']
        config=load_config(method)
        if method=='td':config['model']=str(WORK/'selected-td-model.npz')
        result['rss_before_bytes']=rss()
        def ready():
            a=create_agent(method,config)
            if method=='expectimax':
                from game2048.wrappers.Expectimax.exact import get_solver
                get_solver(256,256.)
            return a
        agent,result['load_ready']=measure(ready)
        for i,b in enumerate(bank[:8]):
            if hasattr(agent,'rng'):agent.rng.seed(7900000+i)
            assert agent.choose(tuple(b)) in legal_actions(tuple(b))
        latencies=[];board_rows=[]
        started=time.perf_counter();cpu=time.process_time()
        for repeat in range(3):
            for i,b in enumerate(bank):
                if hasattr(agent,'rng'):agent.rng.seed(7900000+repeat*len(bank)+i)
                before=time.perf_counter_ns();action=agent.choose(tuple(b));elapsed=time.perf_counter_ns()-before
                assert action in legal_actions(tuple(b))
                latencies.append(elapsed/1000);board_rows.append(dict(repeat=repeat,board_index=i,action=action,microseconds=elapsed/1000))
        result['shared_board_test']=dict(boards=len(bank),rounds=3,calls=len(latencies),wall_seconds=time.perf_counter()-started,
            cpu_seconds=time.process_time()-cpu,mean_us=float(np.mean(latencies)),median_us=float(np.median(latencies)),p95_us=float(np.quantile(latencies,.95)))
        result['shared_board_rows']=board_rows
        games=[]
        for seed in range(6800000,6800010):
            started=time.perf_counter();cpu=time.process_time();row=play_episode(agent,seed=seed)
            games.append(dict(**row,wall_seconds=time.perf_counter()-started,cpu_seconds=time.process_time()-cpu))
        result['episodes']=games
        result['end_to_end']=dict(games=len(games),total_steps=sum(r['steps'] for r in games),
            wall_seconds=sum(r['wall_seconds'] for r in games),cpu_seconds=sum(r['cpu_seconds'] for r in games))
    else:raise ValueError(phase)
    result['peak_rss_bytes']=rss();dump(OUT/'cost'/f'{phase}_{trial}.json',result)
    print(json.dumps(dict(phase=phase,trial=trial,complete=True,peak_rss_bytes=result['peak_rss_bytes'])),flush=True)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--phase');parser.add_argument('--trial',type=int,default=0);args=parser.parse_args()
    if args.phase:worker(args.phase,args.trial);return
    # All experiments must have finished before time comparisons start.
    for filename in ['mcts_status.json','td_status.json']:
        assert json.loads((OUT/filename).read_text(encoding='utf-8'))['status']=='complete',filename
    assert (OUT/'holdout_complete.json').is_file(),'finish holdout before the isolated cost benchmark'
    WORK.mkdir(exist_ok=True,parents=True);(WORK/'training_source').mkdir(exist_ok=True)
    shutil.copy2(OUT/'engine_reference.py',WORK/'training_source/engine_reference.py')
    shutil.copy2(C/'models/TD/optimistic-5tuple-300k.npz',WORK/'selected-td-model.npz')
    from game2048.core import legal_actions
    bank=[];origins=[]
    for name in ['完整Expectimax','MCTS','乐观TD']:
        records=json.loads((ROOT/f'final_report_20261108/output/原版界面汇报素材/{name}_逐步记录.json').read_text(encoding='utf-8'))['records']
        candidates=[r['board'] for r in records if len(legal_actions(tuple(r['board'])))>=2]
        for index in range(32):
            b=candidates[index*(len(candidates)-1)//31];bank.append(b);origins.append(dict(method=name,index=index))
    dump(OUT/'shared_board_bank.json',dict(boards=bank,origins=origins,
        note='32 evenly spaced nontrivial boards from each original selected trajectory; identical bank for all agents; not population-representative'))
    dump(OUT/'cost_design.json',dict(cpu=Path('/proc/cpuinfo').read_text().split('model name')[1].split('\n')[0],
        logical_cpus=os.cpu_count(),affinity_cpu=0,workers=1,repetitions=3,threads_per_process=1,
        seed_range=[6800000,6800009],shared_boards=96,board_rounds_per_repetition=3,
        implementation='repository original inference implementations: C++ exact solver, Python MCTS, NumPy optimistic TD',
        boundaries=dict(prepare='compiled exact library ready; no value table; allocate+solve+persist cache',
            train='JIT compiled; allocate weights+300k episodes+batch statistics; saving separate',
            load='shared environment imports ready; includes lazy algorithm module import, agent construction, weights or value cache loading; OS page cache not forcibly cleared',
            choose='warm agent; only choose() timed per call, shared actual boards, no GUI',
            episode='warm agent; full original environment reset+transitions+decisions to natural terminal, no GUI'),
        hardware_context='grids and holdout completed; sequential fresh worker processes pinned to one logical CPU; system background activity not disabled'))
    tasks=[phase for i in range(3) for phase in [('compile_exact',i),('exact_prepare',i)]]+[('td_train',i) for i in range(3)]
    # Rotate method order between repetitions to reduce systematic order effects.
    methods=['expectimax','mcts','td']
    for trial in range(3):tasks.extend(('online_'+m,trial) for m in methods[trial:]+methods[:trial])
    for phase,trial in tasks:
        if (OUT/'cost'/f'{phase}_{trial}.json').exists():continue
        started=time.perf_counter()
        subprocess.run([sys.executable,'-u',str(Path(__file__)), '--phase',phase,'--trial',str(trial)],check=True)
        print(json.dumps(dict(completed_phase=phase,trial=trial,subprocess_wall_seconds=time.perf_counter()-started)),flush=True)
    results=[json.loads((OUT/'cost'/f'{phase}_{trial}.json').read_text(encoding='utf-8')) for phase,trial in tasks]
    dump(OUT/'cost_all_results.json',results);dump(OUT/'cost_status.json',dict(status='complete',fresh_workers=len(tasks)))
    print('COST_BENCHMARK_COMPLETE',flush=True)

if __name__=='__main__':main()
