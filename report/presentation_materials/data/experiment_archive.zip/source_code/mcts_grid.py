"""6x6 MCTS grid, resumable chunk scheduling, original Gym rules and RNG."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
os.environ['PYGAME_HIDE_SUPPORT_PROMPT']='1'
from pathlib import Path
import argparse,csv,gzip,importlib.util,json,multiprocessing as mp,sys,time

OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1]
spec=importlib.util.spec_from_file_location('old_mcts',ROOT/'本地实验/调参对照_20261110/run_mcts_parameters.py')
M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
BUDGETS=[16,32,64,128,256,512];DEPTHS=[3,6,9,12,18,24]
BASE=6500000;GAMES=2000;CHUNK=500

def dump(path,value):
    temp=Path(path).with_suffix('.tmp');temp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');temp.replace(path)

def job(item):
    b,d,offset=item;folder=OUT/'mcts';folder.mkdir(exist_ok=True)
    path=folder/f'b{b}_d{d}_{offset:04d}.csv.gz'
    if path.exists():return dict(budget=b,depth=d,offset=offset,reused=True)
    agent=M.Configured(dict(simulations=b,depth=d));rows=[];started=time.perf_counter()
    for seed in range(BASE+offset,BASE+offset+CHUNK):rows.append(M.play_episode(agent,seed=seed))
    temp=path.with_suffix('.tmp')
    with gzip.open(temp,'wt',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    temp.replace(path)
    return dict(budget=b,depth=d,offset=offset,wall_seconds=time.perf_counter()-started)

def main():
    p=argparse.ArgumentParser();p.add_argument('--pilot',action='store_true');p.add_argument('--workers',type=int,default=8);args=p.parse_args()
    if args.pilot:
        agent=M.Configured(dict(simulations=128,depth=12));started=time.perf_counter()
        for seed in range(BASE,BASE+100):M.play_episode(agent,seed=seed)
        print(json.dumps(dict(pilot_games=100,seconds=time.perf_counter()-started)),flush=True);return
    M.Configured(dict())
    trace=json.loads((ROOT/'final_report_20261108/output/原版界面汇报素材/乐观TD_逐步记录.json').read_text(encoding='utf-8'))['records']
    boards=[tuple(trace[i]['board']) for i in [10,150]]
    for b in BUDGETS:
        for d in DEPTHS:
            fast=M.Configured(dict(simulations=b,depth=d));ref=M.MCTSAgent(M.MCTSConfig(simulations=b,depth=d))
            for i,board in enumerate(boards):
                fast.seed(7600000+i);ref.rng.seed(7600000+i)
                assert fast.choose(board)==ref.choose(board),(b,d,i,'action')
                assert fast.getstate()==ref.rng.getstate(),(b,d,i,'rng')
    dump(OUT/'mcts_design.json',dict(budgets=BUDGETS,depths=DEPTHS,games_per_cell=GAMES,seed_range=[BASE,BASE+GAMES-1],
        chunk_size=CHUNK,workers=args.workers,validated_action_rng_pairs=72,other_parameters=M.MCTSConfig().__dict__,
        inference_implementation='native kernel verified against repository Python MCTS',primary_metric='final board sum; success=max tile>=256'))
    tasks=sorted([(b,d,k) for b in BUDGETS for d in DEPTHS for k in range(0,GAMES,CHUNK)],key=lambda x:x[0]*x[1],reverse=True)
    started=time.perf_counter();done=0
    with mp.get_context('fork').Pool(args.workers) as pool:
        for result in pool.imap_unordered(job,tasks,chunksize=1):
            done+=1;dump(OUT/'mcts_status.json',dict(status='running',chunks_done=done,total_chunks=len(tasks),seconds=time.perf_counter()-started))
            if done%8==0:print(json.dumps(dict(completed=done,total=len(tasks),last=result,elapsed=time.perf_counter()-started)),flush=True)
    results=[]
    for b in BUDGETS:
        for d in DEPTHS:
            rows=[]
            for k in range(0,GAMES,CHUNK):
                with gzip.open(OUT/f'mcts/b{b}_d{d}_{k:04d}.csv.gz','rt',encoding='utf-8') as f:rows.extend(csv.DictReader(f))
            assert [int(r['seed']) for r in rows]==list(range(BASE,BASE+GAMES))
            results.append(dict(simulations=b,depth=d,games=GAMES,mean_sum=sum(int(r['sum']) for r in rows)/GAMES,
                success_256=sum(int(r['max_tile'])>=256 for r in rows)/GAMES))
    dump(OUT/'mcts_grid_results.json',results);dump(OUT/'mcts_status.json',dict(status='complete',cells=36,games=72000,wall_seconds=time.perf_counter()-started))
    print('MCTS_GRID_COMPLETE',flush=True)

if __name__=='__main__':main()
