"""Fill freed grid workers with the independently selected MCTS holdout."""
from pathlib import Path
import json,subprocess,sys
OUT=Path(__file__).resolve().parent
def main():
    rows=json.loads((OUT/'mcts_grid_results.json').read_text(encoding='utf-8'));chosen={(128,12)}
    for metric in ['mean_sum','success_256']:chosen.update((r['simulations'],r['depth']) for r in sorted(rows,key=lambda r:r[metric],reverse=True)[:3])
    design=dict(mcts_configs=sorted(chosen),td_configs=[],td_training_seeds=[42,137,2026,31415,271828],
        mcts_test_seed_range=[6750000,6752999],selection='top3 each MCTS validation metric plus original; frozen before holdout')
    (OUT/'holdout_design.json').write_text(json.dumps(design,indent=2)+'\n',encoding='utf-8')
    (OUT/'early_mcts_status.json').write_text(json.dumps(dict(status='running'))+'\n',encoding='utf-8')
    subprocess.run([sys.executable,'-u',str(OUT/'holdout.py'),'--method','mcts'],check=True)
    (OUT/'early_mcts_status.json').write_text(json.dumps(dict(status='complete'))+'\n',encoding='utf-8')
if __name__=='__main__':main()
