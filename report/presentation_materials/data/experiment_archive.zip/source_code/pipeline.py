"""Wait for tuning, run independent holdout, then isolated cost measurements."""
from pathlib import Path
import json,subprocess,sys,time
OUT=Path(__file__).resolve().parent
LINUX='/home/panliang/.local/share/game2048-eval-20261110/bin/python'
WSL='/mnt/c/Users/31245/Desktop/game2048-master/本地实验/完整调参_20261110/'
def run(args):subprocess.run(args,check=True)
def main():
    while True:
        ready=[]
        for file in ['td_status.json','mcts_status.json']:
            try:ready.append(json.loads((OUT/file).read_text(encoding='utf-8'))['status']=='complete')
            except (FileNotFoundError,json.JSONDecodeError):ready.append(False)
        if all(ready):break
        time.sleep(10)
    while (OUT/'early_mcts_status.json').exists() and json.loads((OUT/'early_mcts_status.json').read_text())['status']!='complete':time.sleep(10)
    run([sys.executable,'-u',str(OUT/'holdout.py'),'--method','select'])
    run(['wsl.exe','-d','Ubuntu','--',LINUX,'-u',WSL+'holdout.py','--method','mcts'])
    run([sys.executable,'-u',str(OUT/'holdout.py'),'--method','td'])
    (OUT/'holdout_complete.json').write_text(json.dumps(dict(status='complete'))+'\n',encoding='utf-8')
    print('HOLDOUT_COMPLETE_STARTING_ISOLATED_COST',flush=True)
    run(['wsl.exe','-d','Ubuntu','--',LINUX,'-u',WSL+'cost_benchmark.py'])
    print('ALL_EXPERIMENTS_COMPLETE',flush=True)
if __name__=='__main__':main()
