"""35 TD configurations x five training seeds; shared exact prefixes and frozen validation."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import argparse,csv,gzip,json,math,multiprocessing as mp,sys,time
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
import engine_reference as E
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1]
SEEDS=[42,137,2026,31415,271828];TEST=np.arange(6600000,6602000,dtype=np.int64)
ALPHAS=[.01,.03,.05,.1,.2];EPSILONS=[0.,.002,.005,.01,.02]

def dump(path,value):
    temp=Path(path).with_suffix('.tmp');temp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');temp.replace(path)
def configurations():
    out=[]
    for ai,a in enumerate(ALPHAS):
        for ei,e in enumerate(EPSILONS):out.append(dict(id=f'grid_a{ai}_e{ei}',kind='values',alpha_end=a,epsilon_end=e,alpha_switch=210000,epsilon_switch=240000,shape='step'))
    for sa in [150000,210000,270000]:
        for se in [180000,240000,270000]:
            if (sa,se)==(210000,240000):continue
            out.append(dict(id=f'time_a{sa}_e{se}',kind='timing',alpha_end=.03,epsilon_end=.002,alpha_switch=sa,epsilon_switch=se,shape='step'))
    for shape in ['linear','cosine']:out.append(dict(id=shape,kind='shape',alpha_end=.03,epsilon_end=.002,alpha_switch=210000,epsilon_switch=240000,shape=shape))
    for c in out:
        schedule=[]
        for start in range(0,300000,10000):
            vals=[]
            for initial,end,switch in [(.1,c['alpha_end'],c['alpha_switch']),(.02,c['epsilon_end'],c['epsilon_switch'])]:
                if start<switch:v=initial
                elif c['shape']=='step':v=end
                else:
                    ratio=min(1.,max(0.,(start-switch)/(290000-switch)))
                    fraction=ratio if c['shape']=='linear' else (1-math.cos(math.pi*ratio))/2
                    v=initial+(end-initial)*fraction
                vals.append(round(v,12))
            schedule.append(vals)
        c['schedule']=schedule
    assert len(out)==35 and len({tuple(map(tuple,c['schedule'])) for c in out})==35
    return out
CONFIGS=configurations();BYID={c['id']:c for c in CONFIGS}

def run_seed(seed):
    folder=OUT/f'td_seed_{seed}';folder.mkdir(exist_ok=True);p,t=E.patterns(5,True)
    w=np.full((3,16**5),12.5,dtype=np.float32);started=time.perf_counter();nodes=0;finished=0
    def visit(weights,ids,depth,logs):
        nonlocal nodes,finished
        ids=[cid for cid in ids if not (folder/f'{cid}.json').exists()]
        if not ids:return
        if depth==30:
            assert len(ids)==1;cid=ids[0];c=BYID[cid]
            raw=E.evaluate(TEST,6,weights,p,t,0,1);assert not np.any(raw[:,5])
            with gzip.open(folder/f'{cid}_test.csv.gz','wt',encoding='utf-8',newline='') as f:
                np.savetxt(f,raw,delimiter=',',fmt='%.0f',header='seed,sum,max_tile,steps,merge_score,truncated',comments='')
            np.savez_compressed(folder/f'{cid}_weights.npz',weights=weights,positions=p,tables=t)
            result=dict(config=c,train_seed=seed,episodes=300000,mean_sum=float(raw[:,1].mean()),
                success_256=float(np.mean(raw[:,2]>=256)),train_log=logs)
            if seed==42 and cid=='grid_a1_e1':
                with np.load(ROOT/'final_report_20261108/.build/report-pr-20261108/checkout/models/TD/optimistic-5tuple-300k.npz') as original:
                    assert np.array_equal(weights,original['weights']);result['reproduces_original_weights']=True
            dump(folder/f'{cid}.json',result);finished+=1
            print(json.dumps(dict(train_seed=seed,completed=finished,config=cid,mean_sum=result['mean_sum'],seconds=time.perf_counter()-started)),flush=True)
            return
        groups={}
        for cid in ids:groups.setdefault(tuple(BYID[cid]['schedule'][depth]),[]).append(cid)
        for index,((alpha,epsilon),children) in enumerate(groups.items()):
            current=weights if index==len(groups)-1 else weights.copy()
            batch=E.train_batch(current,p,t,10000,seed+depth*10000,alpha,epsilon,0,0.)
            nodes+=1
            entry=dict(episodes=(depth+1)*10000,alpha=alpha,epsilon=epsilon,mean_sum=float(batch[:,0].mean()),success_256=float(np.mean(batch[:,1]>=256)))
            visit(current,children,depth+1,logs+[entry])
    visit(w,list(BYID),0,[])
    results=[json.loads((folder/f'{c["id"]}.json').read_text(encoding='utf-8')) for c in CONFIGS]
    dump(folder/'completion.json',dict(seed=seed,models=35,executed_training_batches=nodes,wall_seconds=time.perf_counter()-started))
    return results

def main():
    p=argparse.ArgumentParser();p.add_argument('--pilot',action='store_true');p.add_argument('--workers',type=int,default=5);args=p.parse_args()
    pos,tables=E.patterns(5,True);w=np.full((3,16**5),12.5,dtype=np.float32)
    if args.pilot:
        E.train_batch(w,pos,tables,1,42,.1,.02,0,0.);E.evaluate(TEST[:1],6,w,pos,tables,0,1)
        started=time.perf_counter();E.train_batch(w,pos,tables,10000,42,.1,.02,0,0.);train_s=time.perf_counter()-started
        started=time.perf_counter();E.evaluate(TEST[:100],6,w,pos,tables,0,1)
        print(json.dumps(dict(pilot_train_games=10000,train_seconds=train_s,pilot_eval_games=100,eval_seconds=time.perf_counter()-started)),flush=True);return
    prefixes={tuple(tuple(p) for p in c['schedule'][:depth]) for c in CONFIGS for depth in range(1,31)}
    dump(OUT/'td_design.json',dict(configurations=CONFIGS,training_seeds=SEEDS,training_episodes=300000,test_seed_range=[6600000,6601999],
        evaluation_epsilon=0.,evaluation_games=2000,workers=args.workers,logical_training_games=35*5*300000,
        executed_training_games_if_no_resume=len(prefixes)*10000*5,shared_prefix_method='exact schedule prefix trie; independent batch RNG seed=train seed+batch start',
        fixed=dict(optimism=300,gamma=1.,lambda_=0.,width=5,symmetry=True),evaluation='rule-equivalent Numba simulator; independent spawn tapes, separate from original main ranking'))
    # Compile once before spawning, so workers load a completed disk cache.
    E.train_batch(w,pos,tables,1,42,.1,.02,0,0.);E.evaluate(TEST[:1],6,w,pos,tables,0,1)
    all_results=[];started=time.perf_counter()
    with ProcessPoolExecutor(max_workers=args.workers,mp_context=mp.get_context('spawn')) as pool:
        for future in as_completed([pool.submit(run_seed,s) for s in SEEDS]):
            all_results.extend(future.result());dump(OUT/'td_status.json',dict(status='running',models=len(all_results),total_models=175,seconds=time.perf_counter()-started))
    dump(OUT/'td_grid_results.json',all_results);dump(OUT/'td_status.json',dict(status='complete',models=len(all_results),wall_seconds=time.perf_counter()-started))
    print('TD_GRID_COMPLETE',flush=True)

if __name__=='__main__':main()
