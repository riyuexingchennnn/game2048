"""Fast, rule-equivalent 3x3 simulator. Each cell is a four-bit log2 tile.

Numba compiles the hot loops on CPU. No trained policy or external game code
is imported. Actions match Game2048Env: left, right, up, down.
"""
import numpy as np
from numba import njit


def _row_tables():
    left = np.zeros(4096, dtype=np.int64)
    scores = np.zeros(4096, dtype=np.float64)
    for key in range(4096):
        cells = [(key >> (4 * i)) & 15 for i in range(3)]
        nonzero = [v for v in cells if v]
        out, i, score = [], 0, 0
        while i < len(nonzero):
            if i + 1 < len(nonzero) and nonzero[i] == nonzero[i + 1]:
                # A rank-16 tile cannot be represented; it is unreachable on
                # this 3x3 board before capacity prevents further merging.
                out.append(nonzero[i] + 1)
                score += 2 ** (nonzero[i] + 1)
                i += 2
            else:
                out.append(nonzero[i])
                i += 1
        left[key] = sum(v << (4 * j) for j, v in enumerate(out))
        scores[key] = score
    return left, scores


ROW_LEFT, ROW_SCORE = _row_tables()


def encode(grid):
    a = np.asarray(grid).ravel()
    if a.size != 9:
        raise ValueError("The fast agent supports exactly 3x3 boards")
    board = 0
    for i, value in enumerate(a):
        v = int(value)
        if v < 0 or v == 1 or (v and (v & (v - 1))) or v >= 65536:
            raise ValueError("Tiles must be zero or powers of two from 2 to 32768")
        board |= (v.bit_length() - 1 if v else 0) << (4 * i)
    return np.int64(board)


def decode(board):
    return np.array([0 if (e := (int(board) >> (4*i)) & 15) == 0 else 1 << e
                     for i in range(9)], dtype=np.int32).reshape(3, 3)


@njit(cache=True)
def move(board, action):
    out, score = np.int64(0), 0.0
    for line in range(3):
        row = 0
        for k in range(3):
            if action == 0:
                pos = line * 3 + k
            elif action == 1:
                pos = line * 3 + 2 - k
            elif action == 2:
                pos = k * 3 + line
            else:
                pos = (2 - k) * 3 + line
            row |= ((board >> (pos * 4)) & 15) << (k * 4)
        merged = ROW_LEFT[row]
        score += ROW_SCORE[row]
        for k in range(3):
            if action == 0:
                pos = line * 3 + k
            elif action == 1:
                pos = line * 3 + 2 - k
            elif action == 2:
                pos = k * 3 + line
            else:
                pos = (2 - k) * 3 + line
            out |= ((merged >> (k * 4)) & 15) << (pos * 4)
    return out, score


@njit(cache=True)
def stats(board):
    mass, maximum, empty = 0, 0, 0
    for i in range(9):
        e = (board >> (4 * i)) & 15
        if e:
            mass += 1 << e
            maximum = max(maximum, e)
        else:
            empty += 1
    return mass, maximum, empty


@njit(cache=True)
def spawn_with_uniforms(board, position_u, tile_u):
    n = stats(board)[2]
    if n == 0:
        return board, 0.0
    index = min(int(position_u * n), n - 1)
    for i in range(9):
        if ((board >> (4 * i)) & 15) == 0:
            if index == 0:
                exponent = 1 if tile_u < .9 else 2
                return board | (np.int64(exponent) << (4 * i)), float(1 << exponent)
            index -= 1
    return board, 0.0


@njit(cache=True)
def spawn(board):
    return spawn_with_uniforms(board, np.random.random(), np.random.random())


@njit(cache=True)
def initial_board():
    b, _ = spawn(np.int64(0))
    return spawn(b)[0]


def patterns(width=5, symmetry=True):
    """Separate tables for base patterns, tied across all D4 orientations."""
    bases = {
        4: [(0, 1, 3, 4), (0, 1, 2, 4)],
        5: [(0, 1, 2, 3, 4), (0, 1, 3, 4, 6), (0, 1, 4, 7, 8)],
        6: [(0, 1, 2, 3, 4, 5), (0, 1, 2, 3, 4, 6)],
    }[width]
    grid = np.arange(9).reshape(3, 3)
    maps = []
    for k in range(4 if symmetry else 1):
        rot = np.rot90(grid, k)
        maps.append(rot.ravel())
        if symmetry:
            maps.append(np.fliplr(rot).ravel())
    positions, tables = [], []
    for t, base in enumerate(bases):
        for mapping in maps:
            positions.append([mapping[x] for x in base])
            tables.append(t)
    return np.array(positions, dtype=np.int64), np.array(tables, dtype=np.int64)


@njit(cache=True)
def value(board, weights, positions, tables):
    total = 0.0
    for f in range(len(tables)):
        key = 0
        for k in range(positions.shape[1]):
            key |= ((board >> (4 * positions[f, k])) & 15) << (4 * k)
        total += weights[tables[f], key]
    return total


@njit(cache=True)
def update(board, delta, alpha, weights, positions, tables):
    # The D4 group can produce repeated (table, key) features. Normalize by
    # ||phi||^2, including these collisions, so a TD step changes V by alpha*delta.
    keys = np.empty(len(tables), dtype=np.int64)
    norm = 0
    for f in range(len(tables)):
        key = 0
        for k in range(positions.shape[1]):
            key |= ((board >> (4 * positions[f, k])) & 15) << (4 * k)
        keys[f] = key
        norm += 1
        for j in range(f):
            if tables[j] == tables[f] and keys[j] == key:
                norm += 2
    adjustment = alpha * delta / norm
    for f in range(len(tables)):
        weights[tables[f], keys[f]] += adjustment


@njit(cache=True)
def action_reward(before, after, merge_score, objective):
    if objective == 1:  # Traditional merge-score objective, deliberately compared.
        return merge_score / 8.0
    if objective == 2 and stats(before)[1] < 8 and stats(after)[1] >= 8:
        return 256.0
    return 0.0


@njit(cache=True)
def greedy_td(board, weights, positions, tables, objective):
    best, action, after = -1e30, -1, board
    for a in range(4):
        nxt, merge_score = move(board, a)
        if nxt != board:
            q = action_reward(board, nxt, merge_score, objective) + value(nxt, weights, positions, tables)
            if q > best:
                best, action, after = q, a, nxt
    return action, after, best


@njit(cache=True)
def train_batch(weights, positions, tables, episodes, seed, alpha=.1,
                epsilon=.01, objective=0, lam=0.0):
    np.random.seed(seed)
    results = np.zeros((episodes, 3), dtype=np.float64)
    trajectory = np.empty(4096, dtype=np.int64)
    rewards = np.empty(4096, dtype=np.float64)
    estimates = np.empty(4096, dtype=np.float64)
    for ep in range(episodes):
        board = initial_board()
        previous, pending, length = np.int64(-1), 0.0, 0
        while True:
            a, after, q = greedy_td(board, weights, positions, tables, objective)
            if a < 0:
                if previous >= 0:
                    if lam == 0:
                        update(previous, pending - value(previous, weights, positions, tables), alpha, weights, positions, tables)
                    else:
                        rewards[length - 1] = pending
                break
            if np.random.random() < epsilon:
                legal = np.empty(4, dtype=np.int64)
                n = 0
                for candidate in range(4):
                    if move(board, candidate)[0] != board:
                        legal[n] = candidate
                        n += 1
                a = legal[np.random.randint(n)]
                after, _ = move(board, a)
            _, merge_score = move(board, a)
            immediate = action_reward(board, after, merge_score, objective)
            estimate = value(after, weights, positions, tables)
            if previous >= 0:
                reward = pending + immediate
                if lam == 0:
                    update(previous, reward + estimate - value(previous, weights, positions, tables), alpha, weights, positions, tables)
                else:
                    rewards[length - 1] = reward
            if length >= 4096:
                raise RuntimeError("Unexpected episode length")
            trajectory[length] = after
            estimates[length] = estimate
            length += 1
            previous = after
            board, spawned = spawn(after)
            pending = spawned if objective != 1 else 0.0
        if lam > 0:
            ret = 0.0
            for i in range(length - 1, -1, -1):
                boot = estimates[i + 1] if i + 1 < length else 0.0
                ret = rewards[i] + (1 - lam) * boot + lam * ret
                update(trajectory[i], ret - value(trajectory[i], weights, positions, tables), alpha, weights, positions, tables)
        mass, maximum, _ = stats(board)
        results[ep] = mass, 1 << maximum, length
    return results


@njit(cache=True)
def heuristic(board, kind=0):
    cells = np.empty(9, dtype=np.int64)
    for i in range(9):
        cells[i] = (board >> (4 * i)) & 15
    mass, maximum, empty = stats(board)
    smooth, pairs, mono = 0.0, 0.0, 0.0
    for r in range(3):
        for c in range(3):
            v = cells[r*3+c]
            for d in range(2):
                if (d == 0 and c < 2) or (d == 1 and r < 2):
                    w = cells[r*3+c+(1 if d == 0 else 3)]
                    if v and w:
                        smooth += abs(v-w)
                        if v == w:
                            pairs += 1
    for direction in range(2):
        for line in range(3):
            inc, dec = 0.0, 0.0
            for k in range(2):
                p = line*3+k if direction == 0 else k*3+line
                q = p+1 if direction == 0 else p+3
                diff = cells[p]-cells[q]
                inc += max(diff, 0)
                dec += max(-diff, 0)
            mono += min(inc, dec)
    corner = max(cells[0], cells[2], cells[6], cells[8]) == maximum
    # Best of eight snake orientations; symmetric evaluator avoids a fixed
    # preferred corner and its associated action-map mistakes.
    snake_best = 0.0
    for orient in range(8):
        val = 0.0
        for j in range(9):
            r, c = j//3, j%3
            if r == 1:
                c = 2-c
            if orient >= 4:
                c = 2-c
            for _ in range(orient % 4):
                r, c = c, 2-r
            val += (9-j) * cells[r*3+c]
        snake_best = max(snake_best, val)
    return 16*empty + 5*pairs - 1.5*smooth - 5*mono + 8*corner + .6*snake_best


@njit(cache=True)
def heuristic_search(board, depth):
    best, action = -1e30, -1
    for a in range(4):
        after, _ = move(board, a)
        if after == board:
            continue
        if depth <= 1:
            q = heuristic(after)
        else:
            n, q = stats(after)[2], 0.0
            for pos in range(9):
                if ((after >> (4*pos)) & 15) == 0:
                    for exponent in range(1, 3):
                        nxt = after | (np.int64(exponent) << (4*pos))
                        _, v = heuristic_search(nxt, depth-1)
                        if v < -1e20:
                            v = -1000.0
                        q += (.9 if exponent == 1 else .1) * v/n
        if q > best:
            best, action = q, a
    return action, best


@njit(cache=True)
def td_search(board, depth, weights, positions, tables, objective):
    best, action = -1e30, -1
    for a in range(4):
        after, score = move(board, a)
        if after == board:
            continue
        immediate = action_reward(board, after, score, objective)
        if depth <= 1:
            q = immediate + value(after, weights, positions, tables)
        else:
            n, q = stats(after)[2], immediate
            for pos in range(9):
                if ((after >> (4*pos)) & 15) == 0:
                    for exponent in range(1, 3):
                        nxt = after | (np.int64(exponent) << (4*pos))
                        _, v = td_search(nxt, depth-1, weights, positions, tables, objective)
                        if v < -1e20:
                            v = 0.0
                        reward = float(1 << exponent) if objective != 1 else 0.0
                        q += (.9 if exponent == 1 else .1) * (reward+v)/n
        if q > best:
            best, action = q, a
    return action, best


@njit(cache=True)
def rollout_action(board, rollouts=16, horizon=60):
    best, action = -1e30, -1
    for a in range(4):
        after, _ = move(board, a)
        if after == board:
            continue
        total = 0.0
        for _ in range(rollouts):
            simulation, _ = spawn(after)
            for _ in range(horizon):
                # Epsilon-greedy heuristic rollout rather than uniformly bad play.
                candidate, _ = heuristic_search(simulation, 1)
                if candidate < 0:
                    break
                if np.random.random() < .15:
                    candidate = np.random.randint(4)
                nxt, _ = move(simulation, candidate)
                if nxt != simulation:
                    simulation, _ = spawn(nxt)
            mass, maximum, _ = stats(simulation)
            total += mass + (256 if maximum >= 8 else 0) + .2*heuristic(simulation)
        if total > best:
            best, action = total, a
    return action


@njit(cache=True)
def choose_action(board, method, weights, positions, tables, objective=0, depth=1):
    # IDs 0..5 are independent baseline families, 6 is learned TD.
    if method == 3:
        return heuristic_search(board, 1)[0]
    if method == 4:
        return heuristic_search(board, depth)[0]
    if method == 5:
        return rollout_action(board)
    if method == 6:
        return td_search(board, depth, weights, positions, tables, objective)[0]
    best, action = -1e30, -1
    for a in range(4):
        nxt, score = move(board, a)
        if nxt == board:
            continue
        if method == 0:
            q = np.random.random()
        elif method == 1:
            q = score + .001*stats(nxt)[2]
        else:
            q = stats(nxt)[2] + .0001*score
        if q > best:
            best, action = q, a
    return action


@njit(cache=True)
def evaluate(seeds, method, weights, positions, tables, objective=0, depth=1):
    # External spawn tape is sampled before action selection. Monte Carlo and
    # random policies cannot consume/change the game's random-number stream.
    results = np.zeros((len(seeds), 6), dtype=np.float64)
    for i in range(len(seeds)):
        seed = seeds[i]
        np.random.seed(seed)
        tape = np.random.random((4098, 2))
        np.random.seed(seed + 10000000)
        board, _ = spawn_with_uniforms(np.int64(0), tape[0,0], tape[0,1])
        board, _ = spawn_with_uniforms(board, tape[1,0], tape[1,1])
        steps, merge_score = 0, 0.0
        while steps < 4096:
            a = choose_action(board, method, weights, positions, tables, objective, depth)
            if a < 0:
                break
            after, score = move(board, a)
            if after == board:
                raise RuntimeError("Policy chose an illegal move")
            board, _ = spawn_with_uniforms(after, tape[steps+2,0], tape[steps+2,1])
            steps += 1
            merge_score += score
        mass, maximum, _ = stats(board)
        results[i, 0] = seed
        results[i, 1] = mass
        results[i, 2] = 1 << maximum
        results[i, 3] = steps
        results[i, 4] = merge_score
        results[i, 5] = 1.0 if steps == 4096 else 0.0
    return results
