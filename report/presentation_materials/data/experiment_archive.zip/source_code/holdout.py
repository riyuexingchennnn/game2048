"""Validation-selected finalists only, fresh frozen-policy holdout, no retraining."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import argparse,csv,gzip,importlib.util,json,multiprocessing as mp,time
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1]
SEEDS=[42,137,2026,31415,271828]
def dump(path,value):
    temp=Path(path).with_suffix('.tmp');temp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');temp.replace(path)

def td_job(item):
    cid,seed=item;folder=OUT/'holdout';folder.mkdir(exist_ok=True)
    resultfile=folder/f'td_{cid}_{seed}.json'
    if resultfile.exists():return json.loads(resultfile.read_text(encoding='utf-8'))
    import engine_reference as E
    with np.load(OUT/f'td_seed_{seed}/{cid}_weights.npz') as a:w,p,t=[a[k].copy() for k in ['weights','positions','tables']]
    raw=E.evaluate(np.arange(6700000,6705000,dtype=np.int64),6,w,p,t,0,1);assert not np.any(raw[:,5])
    with gzip.open(folder/f'td_{cid}_{seed}.csv.gz','wt',encoding='utf-8',newline='') as f:
        np.savetxt(f,raw,delimiter=',',fmt='%.0f',header='seed,sum,max_tile,steps,merge_score,truncated',comments='')
    result=dict(config=cid,train_seed=seed,games=5000,mean_sum=float(raw[:,1].mean()),success_256=float(np.mean(raw[:,2]>=256)))
    dump(resultfile,result);return result

def mc_job(item):
    b,d=item;folder=OUT/'holdout';folder.mkdir(exist_ok=True);resultfile=folder/f'mcts_b{b}_d{d}.json'
    if resultfile.exists():return json.loads(resultfile.read_text(encoding='utf-8'))
    spec=importlib.util.spec_from_file_location('old_mcts',ROOT/'本地实验/调参对照_20261110/run_mcts_parameters.py')
    M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
    agent=M.Configured(dict(simulations=b,depth=d));rows=[]
    for seed in range(6750000,6753000):rows.append(M.play_episode(agent,seed=seed))
    with gzip.open(folder/f'mcts_b{b}_d{d}.csv.gz','wt',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    result=dict(simulations=b,depth=d,games=3000,mean_sum=sum(r['sum'] for r in rows)/3000,success_256=sum(r['max_tile']>=256 for r in rows)/3000)
    dump(resultfile,result);return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--method',choices=['td','mcts','select'],required=True);args=p.parse_args()
    if args.method=='select':
        td=json.loads((OUT/'td_grid_results.json').read_text(encoding='utf-8'));mc=json.loads((OUT/'mcts_grid_results.json').read_text(encoding='utf-8'))
        ids=sorted({r['config']['id'] for r in td});summary=[]
        for cid in ids:
            rows=[r for r in td if r['config']['id']==cid]
            assert len(rows)==5
            summary.append(dict(id=cid,mean_sum=float(np.mean([r['mean_sum'] for r in rows])),success_256=float(np.mean([r['success_256'] for r in rows]))))
        chosen_td={'grid_a1_e1'}
        for metric in ['mean_sum','success_256']:chosen_td.update(r['id'] for r in sorted(summary,key=lambda x:x[metric],reverse=True)[:2])
        chosen_mc={(128,12)}
        for metric in ['mean_sum','success_256']:chosen_mc.update((r['simulations'],r['depth']) for r in sorted(mc,key=lambda x:x[metric],reverse=True)[:3])
        design=dict(td_configs=sorted(chosen_td),mcts_configs=sorted(chosen_mc),td_training_seeds=SEEDS,
            td_test_seed_range=[6700000,6704999],mcts_test_seed_range=[6750000,6752999],
            selection='union of top2 TD and top3 MCTS for each validation metric plus original configuration; selected before opening holdout',
            weights_frozen=True,formal_original_models_unchanged=True)
        dump(OUT/'holdout_design.json',design);print(json.dumps(design),flush=True);return
    design=json.loads((OUT/'holdout_design.json').read_text(encoding='utf-8'))
    if args.method=='td':tasks=[(cid,s) for cid in design['td_configs'] for s in SEEDS];func=td_job;workers=5
    else:tasks=design['mcts_configs'];func=mc_job;workers=min(6,len(tasks))
    results=[]
    with ProcessPoolExecutor(max_workers=workers,mp_context=mp.get_context('spawn')) as pool:
        for f in as_completed([pool.submit(func,item) for item in tasks]):
            row=f.result();results.append(row);print(json.dumps(dict(method=args.method,done=len(results),total=len(tasks),result=row)),flush=True)
    dump(OUT/f'{args.method}_holdout_results.json',results)

if __name__=='__main__':main()
